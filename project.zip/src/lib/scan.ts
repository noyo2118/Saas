export type ScanResult = {
  target: string;
  score: number;
  verdict: "Trusted" | "Suspicious" | "High risk" | "Critical";
  fraudScore: number;
  ssl: { valid: boolean; issuer: string; expires: string; grade: string };
  whois: { registrar: string; created: string; country: string; ageDays: number };
  ip: { address: string; asn: string; org: string; country: string; abuse: number };
  blacklists: { name: string; listed: boolean }[];
  indicators: { label: string; status: "ok" | "warn" | "bad" }[];
  ai: string;
};

export function deriveScan(target: string): ScanResult {
  // deterministic-ish hash for reproducible results per target
  let h = 0;
  for (let i = 0; i < target.length; i++) h = (h * 31 + target.charCodeAt(i)) >>> 0;
  const r = (n: number) => Math.abs((h >> n) % 100);
  const score = Math.max(8, Math.min(99, 30 + r(2) % 70));
  const verdict: ScanResult["verdict"] =
    score >= 85 ? "Trusted" : score >= 60 ? "Suspicious" : score >= 35 ? "High risk" : "Critical";
  const fraud = 100 - score + (r(5) % 10) - 5;
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(target);
  return {
    target,
    score,
    verdict,
    fraudScore: Math.max(1, Math.min(100, fraud)),
    ssl: {
      valid: score > 50,
      issuer: score > 70 ? "Let's Encrypt R3" : "Self-signed CA",
      expires: score > 50 ? "2026-08-14" : "2024-02-09 (expired)",
      grade: score > 80 ? "A+" : score > 60 ? "B" : score > 40 ? "C" : "F",
    },
    whois: {
      registrar: score > 60 ? "MarkMonitor Inc." : "NameSilo, LLC",
      created: score > 70 ? "2011-03-22" : "2024-09-14",
      country: ["US", "RU", "CN", "DE", "BR"][r(7) % 5],
      ageDays: score > 70 ? 4800 : 38,
    },
    ip: {
      address: isIp ? target : `203.0.113.${r(11) % 250 + 1}`,
      asn: `AS${13000 + (r(13) % 9999)}`,
      org: score > 70 ? "Cloudflare, Inc." : "OVH SAS",
      country: ["US", "FR", "DE", "RU", "NL"][r(17) % 5],
      abuse: 100 - score,
    },
    blacklists: [
      { name: "Spamhaus",      listed: score < 50 },
      { name: "AbuseIPDB",     listed: score < 60 },
      { name: "URLhaus",       listed: score < 45 },
      { name: "PhishTank",     listed: score < 40 },
      { name: "Google SB",     listed: score < 35 },
      { name: "OpenPhish",     listed: score < 50 },
      { name: "Cisco Talos",   listed: score < 30 },
      { name: "VirusTotal",    listed: score < 55 },
    ],
    indicators: [
      { label: "Domain age > 1 year", status: score > 70 ? "ok" : "bad" },
      { label: "Valid HTTPS chain",   status: score > 50 ? "ok" : "warn" },
      { label: "No phishing kit match", status: score > 60 ? "ok" : "bad" },
      { label: "Reputation > 70",     status: score > 70 ? "ok" : score > 40 ? "warn" : "bad" },
      { label: "WHOIS transparency",  status: score > 60 ? "ok" : "warn" },
      { label: "No C2 beacon pattern",status: score > 45 ? "ok" : "bad" },
    ],
    ai:
      verdict === "Trusted"
        ? `${target} shows strong reputation across 84 feeds. Domain has stable history, valid TLS, and no behavioural anomalies. Confidence: high.`
        : verdict === "Suspicious"
          ? `${target} exhibits mixed signals — recent registration and partial TLS validation. Recommend monitoring before trusting.`
          : verdict === "High risk"
            ? `${target} matches active phishing kit signatures and forwards credentials to an untrusted endpoint. Block recommended.`
            : `${target} is currently active in a credential-harvesting campaign. Multi-feed correlation and beacon analysis confirm critical risk.`,
  };
}
