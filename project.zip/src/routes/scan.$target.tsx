import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { CheckCircle2, XCircle, AlertTriangle, ShieldCheck, Lock, Globe2, FileSearch, Link2 } from "lucide-react";

import { AppShell } from "@/components/layout/AppShell";
import { GlassCard } from "@/components/ui-custom/GlassCard";
import { GlowBadge, StatusDot } from "@/components/ui-custom/GlowBadge";
import { TrustScoreRing } from "@/components/viz/TrustScoreRing";
import { Terminal } from "@/components/viz/Terminal";
import { RiskBars } from "@/components/viz/RiskBars";
import { AIExplain } from "@/components/viz/AIExplain";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScanBeam } from "@/components/effects/Backgrounds";
import { deriveScan } from "@/lib/scan";
import { dispatchEvent as dispatchNeural, setThreatLevel } from "@/lib/neural-core";

export const Route = createFileRoute("/scan/$target")({
  head: ({ params }) => ({
    meta: [
      { title: `Scan · ${params.target} — TrustScan` },
      { name: "description", content: `AI-generated cyber intelligence report for ${params.target}.` },
      { property: "og:title", content: `Scan · ${params.target}` },
      { property: "og:description", content: `Live AI verdict and intelligence for ${params.target}.` },
    ],
  }),
  component: ScanPage,
});

function ScanPage() {
  const { target } = Route.useParams();
  const result = deriveScan(target);
  const [scanning, setScanning] = useState(true);
  const [progress, setProgress] = useState(0);
  const stages = ["DNS", "TLS", "WHOIS", "Feeds", "AI"];

  useEffect(() => {
    setScanning(true); setProgress(0);
    dispatchNeural("scan-start", { target });
    const id = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(id);
          setScanning(false);
          // Threat = inverse of score, scaled to 0..1.
          setThreatLevel(Math.max(0, Math.min(1, (100 - result.score) / 100)));
          dispatchNeural("scan-complete", { score: result.score });
          return 100;
        }
        return p + 4;
      });
    }, 60);
    return () => clearInterval(id);
  }, [target, result.score]);

  const tone = result.score >= 85 ? "green" : result.score >= 60 ? "cyan" : result.score >= 35 ? "amber" : "red";

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl space-y-5 sm:space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground sm:text-xs">
              <Link2 className="h-3.5 w-3.5" /> Intelligence report
            </div>
            <h1 className="mt-2 font-display text-xl font-semibold tracking-tight break-all sm:text-2xl lg:text-3xl">{target}</h1>
          </div>
          <GlowBadge tone={tone}>{result.verdict}</GlowBadge>
        </div>

        {/* Hero scan */}
        <GlassCard variant="holographic" className="relative overflow-hidden p-4 sm:p-6">
          {scanning && <ScanBeam />}
          <div className="grid items-center gap-6 sm:gap-8 lg:grid-cols-[auto_1fr]">
            <div className="flex flex-col items-center">
              <TrustScoreRing score={result.score} size={200} thickness={14} />
            </div>
            <div className="space-y-4 sm:space-y-5">
              <div>
                <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Scan progress</div>
                <div className="mt-2 grid grid-cols-5 gap-1.5">
                  {stages.map((s, i) => {
                    const filled = progress >= ((i + 1) / stages.length) * 100;
                    return (
                      <div key={s} className="space-y-1.5">
                        <div className="h-1.5 overflow-hidden rounded-full bg-[color-mix(in_oklab,var(--surface-2)_70%,transparent)]">
                          <motion.div
                            initial={{ width: 0 }} animate={{ width: filled ? "100%" : "0%" }}
                            transition={{ duration: 0.5, delay: i * 0.05 }}
                            className="h-full rounded-full"
                            style={{ background: "linear-gradient(90deg, var(--neon-cyan), var(--neon-violet))" }}
                          />
                        </div>
                        <div className={`text-[10px] uppercase tracking-[0.18em] ${filled ? "text-foreground" : "text-muted-foreground"}`}>{s}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <AIExplain text={result.ai} />
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Stat label="Fraud score" value={`${result.fraudScore}/100`} tone={tone} />
                <Stat label="SSL grade" value={result.ssl.grade} tone={result.ssl.valid ? "green" : "red"} />
                <Stat label="Domain age" value={`${result.whois.ageDays}d`} tone={result.whois.ageDays > 365 ? "green" : "amber"} />
                <Stat label="ASN" value={result.ip.asn} tone="cyan" />
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Tabs */}
        <Tabs defaultValue="overview" className="w-full">
          <div className="-mx-1 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            <TabsList className="glass mx-1 inline-flex h-11 w-max rounded-full p-1">
              {["overview", "ssl", "whois", "blacklist", "ip"].map((v) => (
                <TabsTrigger key={v} value={v} className="rounded-full px-3.5 text-xs capitalize sm:px-4 sm:text-sm data-[state=active]:bg-[color-mix(in_oklab,var(--neon-cyan)_15%,transparent)] data-[state=active]:text-foreground">
                  {v === "ip" ? "IP intel" : v}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value="overview" className="mt-5">
            <div className="grid gap-5 lg:grid-cols-3">
              <GlassCard className="p-5 lg:col-span-2">
                <div className="mb-3 font-display text-base font-semibold">Indicators</div>
                <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {result.indicators.map((it) => (
                    <li key={it.label} className="flex items-center gap-3 rounded-lg border border-border bg-[color-mix(in_oklab,var(--surface-2)_50%,transparent)] p-3 text-sm">
                      {it.status === "ok" ? <CheckCircle2 className="h-4 w-4 text-neon-green" /> :
                       it.status === "warn" ? <AlertTriangle className="h-4 w-4 text-neon-amber" /> :
                       <XCircle className="h-4 w-4 text-neon-red" />}
                      <span>{it.label}</span>
                    </li>
                  ))}
                </ul>
              </GlassCard>
              <GlassCard className="p-5">
                <div className="mb-3 font-display text-base font-semibold">Risk breakdown</div>
                <RiskBars />
              </GlassCard>
              <div className="lg:col-span-3"><Terminal /></div>
            </div>
          </TabsContent>

          <TabsContent value="ssl" className="mt-5">
            <GlassCard className="p-5">
              <div className="mb-3 flex items-center gap-2 font-display text-base font-semibold"><Lock className="h-4 w-4 text-neon-cyan" /> TLS / SSL inspection</div>
              <div className="grid gap-3 sm:grid-cols-3">
                <Field label="Status" value={result.ssl.valid ? "Valid" : "Invalid"} tone={result.ssl.valid ? "green" : "red"} />
                <Field label="Issuer" value={result.ssl.issuer} />
                <Field label="Expires" value={result.ssl.expires} tone={result.ssl.valid ? "cyan" : "red"} />
                <Field label="Grade" value={result.ssl.grade} tone={result.ssl.valid ? "green" : "red"} />
                <Field label="HSTS" value={result.score > 60 ? "Enabled" : "Missing"} />
                <Field label="OCSP" value="Stapled" />
              </div>
            </GlassCard>
          </TabsContent>

          <TabsContent value="whois" className="mt-5">
            <GlassCard className="p-5">
              <div className="mb-3 flex items-center gap-2 font-display text-base font-semibold"><FileSearch className="h-4 w-4 text-neon-cyan" /> WHOIS</div>
              <div className="grid gap-3 sm:grid-cols-3">
                <Field label="Registrar" value={result.whois.registrar} />
                <Field label="Created" value={result.whois.created} />
                <Field label="Country" value={result.whois.country} />
                <Field label="Age" value={`${result.whois.ageDays} days`} tone={result.whois.ageDays > 365 ? "green" : "amber"} />
                <Field label="Privacy" value="Disclosed" />
                <Field label="Status" value="OK" />
              </div>
            </GlassCard>
          </TabsContent>

          <TabsContent value="blacklist" className="mt-5">
            <GlassCard className="p-5">
              <div className="mb-3 flex items-center gap-2 font-display text-base font-semibold"><ShieldCheck className="h-4 w-4 text-neon-cyan" /> Blacklist matrix</div>
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                {result.blacklists.map((b) => (
                  <div key={b.name} className="flex items-center justify-between rounded-lg border border-border bg-[color-mix(in_oklab,var(--surface-2)_50%,transparent)] px-3 py-2.5 text-sm">
                    <span>{b.name}</span>
                    {b.listed
                      ? <GlowBadge tone="red">Listed</GlowBadge>
                      : <GlowBadge tone="green">Clean</GlowBadge>}
                  </div>
                ))}
              </div>
            </GlassCard>
          </TabsContent>

          <TabsContent value="ip" className="mt-5">
            <GlassCard className="p-5">
              <div className="mb-3 flex items-center gap-2 font-display text-base font-semibold"><Globe2 className="h-4 w-4 text-neon-cyan" /> IP intelligence</div>
              <div className="grid gap-3 sm:grid-cols-3">
                <Field label="Address" value={result.ip.address} />
                <Field label="ASN" value={result.ip.asn} />
                <Field label="Org" value={result.ip.org} />
                <Field label="Country" value={result.ip.country} />
                <Field label="Abuse score" value={`${result.ip.abuse}/100`} tone={result.ip.abuse > 60 ? "red" : result.ip.abuse > 30 ? "amber" : "green"} />
                <Field label="Reverse DNS" value="—" />
              </div>
            </GlassCard>
          </TabsContent>
        </Tabs>

        <div className="flex items-center justify-center pt-2 text-xs text-muted-foreground">
          <StatusDot tone={tone} /> &nbsp; Report generated by TrustScan AI v4.2 · 84 feeds correlated
        </div>
      </div>
    </AppShell>
  );
}

function Stat({ label, value, tone = "cyan" }: { label: string; value: string; tone?: "cyan" | "violet" | "green" | "red" | "amber" }) {
  return (
    <div className="rounded-xl border border-border bg-[color-mix(in_oklab,var(--surface-2)_50%,transparent)] p-3">
      <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
      <div className={`mt-1 font-display text-xl font-semibold text-neon-${tone}`}>{value}</div>
    </div>
  );
}

function Field({ label, value, tone }: { label: string; value: string; tone?: "cyan" | "violet" | "green" | "red" | "amber" }) {
  return (
    <div className="rounded-xl border border-border bg-[color-mix(in_oklab,var(--surface-2)_50%,transparent)] p-4">
      <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
      <div className={`mt-1 font-mono text-sm ${tone ? `text-neon-${tone}` : ""}`}>{value}</div>
    </div>
  );
}
