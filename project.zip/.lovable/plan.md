## Goals

1. Remove the "Launch" button from the marketing nav (mobile + desktop).
2. Replace the password-based auth with email-only OTP login (enter email → receive 6-digit code → enter code → logged in). No password, no SSO button.
3. Give users a clear way to cancel/back out of the sign-in/sign-up flow.

## 1. Marketing nav cleanup (`MarketingShell.tsx`)

- Remove the `<NeonButton asChild><Link to="/signup">Launch</Link></NeonButton>` from the desktop nav.
- Replace it with a single `Sign in` link (desktop) that goes to `/login`.
- Mobile sheet: drop the duplicate Launch CTA, keep the "Sign in" link at the bottom.
- Footer "Account" column: remove "Create account" (since signup is now just email entry on the same page) — keep Sign in / Settings / Admin.

## 2. Email OTP authentication

Lovable Cloud is **not yet enabled** on this project, and OTP delivery requires a real backend (Supabase auth + email). Step one of implementation is to enable Lovable Cloud so we can use `supabase.auth.signInWithOtp` and `verifyOtp`.

Once Cloud is on, rebuild `src/routes/login.tsx` (and reuse it for `/signup`) as a single two-step flow:

```
┌─────────────────────────────────┐        ┌─────────────────────────────────┐
│  Step 1 — Enter email           │   →    │  Step 2 — Enter 6-digit code    │
│  [you@company.com]              │        │  [_ _ _ _ _ _]                  │
│  [ Send code ]   [ Cancel ]     │        │  [ Verify ]  [ Use a different  │
│                                 │        │              email ]  [ Cancel ]│
└─────────────────────────────────┘        └─────────────────────────────────┘
```

Behavior:
- **Step 1** — email field + `Send code` button. On submit call `supabase.auth.signInWithOtp({ email, options: { shouldCreateUser: true, emailRedirectTo: window.location.origin + '/dashboard' } })`. `shouldCreateUser: true` means the same screen handles both sign-in and first-time sign-up — no separate signup form needed.
- **Step 2** — 6-digit code input (use existing `Input OTP` shadcn component) + `Verify` button. On submit call `supabase.auth.verifyOtp({ email, token, type: 'email' })`. On success, navigate to `/dashboard`.
- **Cancel** button on both steps → navigates back to `/` (home). This is the missing exit path the user flagged.
- **"Use a different email"** on step 2 → returns to step 1 with the field cleared.
- **Resend code** link on step 2 with a 30-second cooldown timer.
- Inline error messages (invalid email, wrong code, expired code, rate-limit) shown under the field.
- Remove: password field, "Continue with SSO" button, "Full name" field, the "Create account / Sign in" toggle link at the bottom (no longer needed since one flow does both).

`/signup` route stays for back-compat but renders the exact same component as `/login` (same email-OTP flow).

## 3. Hero / CTA copy

The landing hero currently says "Launch console" and the final CTA says "Start free". Update both CTAs to a single `Sign in` action pointing at `/login` so the messaging matches the new auth model (no separate signup).

## Out of scope

- Dashboard, scan, settings, admin pages — auth gating those routes is a separate pass and not part of this request.
- Password reset (no longer needed — there is no password).
- Custom email template branding for the OTP email (Lovable Cloud's default template is fine for now; can polish later).

## Technical notes

- Enabling Lovable Cloud provisions Supabase under the hood and creates `src/integrations/supabase/client.ts`. We'll import `supabase` from there.
- The `input-otp` shadcn component is already installed (`src/components/ui/input-otp.tsx`).
- No new dependencies, no schema migrations, no edge functions.
- All existing visual styling (GlassCard, NeonButton, Aurora backdrop, ThreatGlobe panel) is preserved — only the form contents change.

## Deliverable

After implementation:
- Nav has no "Launch" button — just `Sign in`.
- `/login` and `/signup` show a clean two-step OTP flow with a visible Cancel button on every step.
- Submitting a real email actually sends a code and logs the user in on verification.
