
from cachetools import TTLCache

cache = TTLCache(maxsize=1000, ttl=300)

def get_cached(url):
    return cache.get(url)

def set_cache(url, data):
    cache[url] = data
