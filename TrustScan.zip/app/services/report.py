"""
TrustScan Enterprise PDF Report
Real data only — every value comes directly from the scanner.
AI sections use Puter/Claude output when available, rule-based fallback otherwise.
"""
import io, math, asyncio, hashlib, time, base64
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether
)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import Flowable

# ── PALETTE ──────────────────────────────────────────────────────────────────
C_BG        = colors.HexColor("#060912")
C_SURFACE   = colors.HexColor("#0d1117")
C_PANEL     = colors.HexColor("#111827")
C_PANEL_ALT = colors.HexColor("#0f1829")
C_BORDER    = colors.HexColor("#1e2d45")
C_ACCENT    = colors.HexColor("#2563eb")
C_ACCENT_L  = colors.HexColor("#3b82f6")
C_ACCENT2   = colors.HexColor("#0ea5e9")
C_PURPLE    = colors.HexColor("#8b5cf6")
C_SAFE      = colors.HexColor("#10b981")
C_SAFE_BG   = colors.HexColor("#022c22")
C_CAUTION   = colors.HexColor("#f59e0b")
C_CAUTION_BG= colors.HexColor("#1c1500")
C_RISKY     = colors.HexColor("#ef4444")
C_RISKY_BG  = colors.HexColor("#1f0a0a")
C_TEXT      = colors.HexColor("#e2e8f0")
C_TEXT_SEC  = colors.HexColor("#94a3b8")
C_MUTED     = colors.HexColor("#475569")
C_WHITE     = colors.white
C_HDR_BG    = colors.HexColor("#080d18")

VERDICT_COLOR = {"SAFE": C_SAFE, "CAUTION": C_CAUTION, "RISKY": C_RISKY}
PW = 515


# ── CUSTOM FLOWABLES ─────────────────────────────────────────────────────────

class ScoreDonut(Flowable):
    def __init__(self, score, verdict, size=130):
        super().__init__()
        self.score = score; self.verdict = verdict
        self.size = size; self.width = size; self.height = size

    def draw(self):
        c = self.canv
        cx = cy = self.size / 2
        r = self.size / 2 - 10
        rw = 14
        col = VERDICT_COLOR.get(self.verdict, C_ACCENT_L)
        c.setStrokeColor(C_BORDER); c.setLineWidth(rw)
        c.circle(cx, cy, r, stroke=1, fill=0)
        c.setStrokeColor(col); c.setLineWidth(rw)
        sweep = 360 * (self.score / 100)
        if sweep > 0:
            c.arc(cx-r, cy-r, cx+r, cy+r, startAng=90-sweep, extent=sweep)
            ea = math.radians(90-sweep)
            c.setFillColor(col)
            c.circle(cx+r*math.cos(ea), cy+r*math.sin(ea), rw/2+2, stroke=0, fill=1)
        c.setFillColor(C_BG)
        c.circle(cx, cy, r-rw/2-3, stroke=0, fill=1)
        c.setFillColor(col); c.setFont("Helvetica-Bold", 30)
        c.drawCentredString(cx, cy+8, str(self.score))
        c.setFillColor(C_MUTED); c.setFont("Helvetica", 7)
        c.drawCentredString(cx, cy-14, "TRUST SCORE / 100")
        c.setFillColor(col); c.setFont("Helvetica-Bold", 8)
        c.drawCentredString(cx, cy-26, self.verdict)


class SectionHeader(Flowable):
    def __init__(self, num, title, subtitle="", color=None, width=PW):
        super().__init__()
        self._num=num; self._title=title; self._subtitle=subtitle
        self._color=color or C_ACCENT_L; self._w=width
        self.width=width; self.height=48 if subtitle else 36

    def draw(self):
        c = self.canv
        c.setFillColor(C_PANEL)
        c.roundRect(0, 0, self._w, self.height, 4, stroke=0, fill=1)
        c.setFillColor(self._color)
        c.roundRect(0, 0, 5, self.height, 2, stroke=0, fill=1)
        c.setFillColor(self._color); c.setFont("Helvetica-Bold", 8)
        c.drawString(18, self.height-14, f"SECTION {self._num:02d}")
        c.setFillColor(C_WHITE); c.setFont("Helvetica-Bold", 12)
        c.drawString(18, self.height-27, self._title.upper())
        if self._subtitle:
            c.setFillColor(C_TEXT_SEC); c.setFont("Helvetica", 8)
            c.drawString(18, 10, self._subtitle)
        c.setFillColor(self._color)
        c.circle(self._w-14, self.height/2, 4, stroke=0, fill=1)
        c.setFillColor(C_BG)
        c.circle(self._w-14, self.height/2, 2, stroke=0, fill=1)


class CheckRow(Flowable):
    def __init__(self, label, ok, value_text, detail="", width=PW):
        super().__init__()
        self._label=label; self._ok=ok; self._val=value_text
        self._detail=detail; self._w=width
        self.width=width; self.height=40 if detail else 32

    def draw(self):
        c = self.canv
        c.setFillColor(C_PANEL)
        c.roundRect(0, 0, self._w, self.height, 3, stroke=0, fill=1)
        c.setStrokeColor(C_BORDER); c.setLineWidth(0.4)
        c.line(0, 0, self._w, 0)
        dot = C_SAFE if self._ok else C_RISKY
        cy  = self.height/2 + (4 if self._detail else 0)
        c.setFillColor(dot); c.circle(18, cy, 5, stroke=0, fill=1)
        c.setFillColor(C_WHITE); c.circle(18, cy, 2, stroke=0, fill=1)
        c.setFillColor(C_TEXT); c.setFont("Helvetica-Bold", 9)
        c.drawString(34, self.height-16, self._label)
        if self._detail:
            c.setFillColor(C_TEXT_SEC); c.setFont("Helvetica", 7.5)
            c.drawString(34, 8, self._detail[:90])
        pw = 200; px = self._w-pw-10
        py = self.height/2-10+(4 if self._detail else 0)
        bg = C_SAFE_BG if self._ok else C_RISKY_BG
        bc = C_SAFE    if self._ok else C_RISKY
        c.setFillColor(bg)
        c.roundRect(px, py, pw, 20, 4, stroke=0, fill=1)
        c.setStrokeColor(bc); c.setLineWidth(0.5)
        c.roundRect(px, py, pw, 20, 4, stroke=1, fill=0)
        c.setFillColor(bc); c.setFont("Helvetica-Bold", 7.5)
        val = (self._val[:32]+"…") if len(self._val)>34 else self._val
        c.drawCentredString(px+pw/2, py+6, val)


class StatBox(Flowable):
    def __init__(self, label, value, sub="", color=None, width=120):
        super().__init__()
        self._label=label; self._value=value; self._sub=sub
        self._color=color or C_ACCENT_L; self.width=width; self.height=82

    def draw(self):
        c=self.canv; w,h=self.width,self.height
        c.setFillColor(C_PANEL)
        c.roundRect(0,0,w,h,5,stroke=0,fill=1)
        c.setStrokeColor(C_BORDER); c.setLineWidth(0.5)
        c.roundRect(0,0,w,h,5,stroke=1,fill=0)
        c.setFillColor(self._color)
        c.roundRect(0,h-4,w,4,2,stroke=0,fill=1)
        c.setFillColor(C_MUTED); c.setFont("Helvetica",6.5)
        c.drawString(10,h-18,self._label.upper())
        fs = 13 if len(str(self._value))>8 else 18
        c.setFillColor(self._color); c.setFont("Helvetica-Bold",fs)
        c.drawString(10,h-44,str(self._value))
        if self._sub:
            c.setFillColor(C_TEXT_SEC); c.setFont("Helvetica",7)
            c.drawString(10,12,self._sub)
        c.setFillColor(self._color)
        c.roundRect(0,0,w,3,1,stroke=0,fill=1)


class RiskGauge(Flowable):
    def __init__(self, score, width=PW):
        super().__init__()
        self.score=score; self.width=width; self.height=36

    def draw(self):
        c=self.canv; bh,by,bw=12,18,self.width
        segs=[(0,bw*.40,C_RISKY_BG,C_RISKY),(bw*.40,bw*.30,C_CAUTION_BG,C_CAUTION),(bw*.70,bw*.30,C_SAFE_BG,C_SAFE)]
        for sx,sw,bg,col in segs:
            c.setFillColor(bg); c.roundRect(sx,by,sw,bh,2,stroke=0,fill=1)
            c.setStrokeColor(col); c.setLineWidth(0.3)
            c.roundRect(sx,by,sw,bh,2,stroke=1,fill=0)
        for txt,x in [("RISKY  0–49",bw*.20),("CAUTION  50–79",bw*.55),("SAFE  80–100",bw*.85)]:
            c.setFillColor(C_MUTED); c.setFont("Helvetica",6)
            c.drawCentredString(x,by-9,txt)
        mx=max(8,min((self.score/100)*bw,bw-8))
        c.setFillColor(C_WHITE); c.setStrokeColor(C_BG); c.setLineWidth(2)
        c.circle(mx,by+bh/2,8,stroke=1,fill=1)
        c.setFillColor(C_BG); c.setFont("Helvetica-Bold",6.5)
        c.drawCentredString(mx,by+bh/2-2.5,str(self.score))


class PageDivider(Flowable):
    def __init__(self, width=PW):
        super().__init__()
        self.width=width; self.height=18

    def draw(self):
        c=self.canv; cx=self.width/2
        c.setStrokeColor(C_BORDER); c.setLineWidth(0.5)
        c.line(0,9,cx-26,9); c.line(cx+26,9,self.width,9)
        c.setFillColor(C_BORDER)
        c.circle(cx,9,4,stroke=0,fill=1)
        c.circle(cx-14,9,2,stroke=0,fill=1)
        c.circle(cx+14,9,2,stroke=0,fill=1)


class AIBadge(Flowable):
    def __init__(self, powered=True, width=PW):
        super().__init__()
        self.powered=powered; self.width=width; self.height=16

    def draw(self):
        c=self.canv
        label = "✦ AI SCAM ANALYSIS — CLAUDE VIA PUTER.COM" if self.powered else "✦ RULE-BASED ANALYSIS (PUTER TOKEN NOT CONFIGURED)"
        col   = C_PURPLE if self.powered else C_MUTED
        c.setFillColor(col); c.setFont("Helvetica-Bold",6.5)
        c.drawString(0,5,label)
        c.setStrokeColor(col); c.setLineWidth(0.3)
        c.line(0,2,self.width,2)


# ── STYLES ───────────────────────────────────────────────────────────────────

def styles():
    return {
        "cover_title": ParagraphStyle("ct", fontName="Helvetica-Bold", fontSize=28,
            textColor=C_WHITE, leading=34, spaceAfter=6),
        "cover_sub":   ParagraphStyle("cs", fontName="Helvetica", fontSize=10,
            textColor=C_TEXT_SEC, leading=16, spaceAfter=6),
        "url_s":       ParagraphStyle("us", fontName="Helvetica-Bold", fontSize=11,
            textColor=C_ACCENT_L, spaceAfter=6),
        "body":        ParagraphStyle("bo", fontName="Helvetica", fontSize=9.5,
            textColor=C_TEXT, leading=16, spaceAfter=6, alignment=TA_JUSTIFY),
        "label":       ParagraphStyle("la", fontName="Helvetica-Bold", fontSize=7,
            textColor=C_MUTED, spaceAfter=2),
        "footer":      ParagraphStyle("fo", fontName="Helvetica", fontSize=7,
            textColor=C_MUTED, alignment=TA_CENTER),
        "th":          ParagraphStyle("th", fontName="Helvetica-Bold", fontSize=8,
            textColor=C_MUTED),
        "tv":          ParagraphStyle("tv", fontName="Helvetica", fontSize=9,
            textColor=C_TEXT),
        "tok":         ParagraphStyle("tok", fontName="Helvetica-Bold", fontSize=9,
            textColor=C_SAFE),
        "tbad":        ParagraphStyle("tbad", fontName="Helvetica-Bold", fontSize=9,
            textColor=C_RISKY),
        "twarn":       ParagraphStyle("twarn", fontName="Helvetica-Bold", fontSize=9,
            textColor=C_CAUTION),
        "ttot":        ParagraphStyle("ttot", fontName="Helvetica-Bold", fontSize=10,
            textColor=C_WHITE),
        "vtext":       ParagraphStyle("vt", fontName="Helvetica-Bold", fontSize=11,
            textColor=C_BG, alignment=TA_CENTER),
        "mono":        ParagraphStyle("mo", fontName="Courier", fontSize=8,
            textColor=C_ACCENT_L, leading=12),
        "rec_title":   ParagraphStyle("rt", fontName="Helvetica-Bold", fontSize=10,
            textColor=C_WHITE, spaceAfter=4),
        "rec_body":    ParagraphStyle("rb", fontName="Helvetica", fontSize=9,
            textColor=C_TEXT_SEC, leading=14),
    }


# ── PAGE BACKGROUNDS ─────────────────────────────────────────────────────────

def cover_bg(canvas, doc):
    canvas.saveState()
    w,h = A4
    canvas.setFillColor(C_BG); canvas.rect(0,0,w,h,stroke=0,fill=1)
    canvas.setFillColor(C_PANEL)
    p=canvas.beginPath(); p.moveTo(w*.50,h); p.lineTo(w,h); p.lineTo(w,h*.40); p.close()
    canvas.drawPath(p,fill=1,stroke=0)
    canvas.setFillColor(C_ACCENT); canvas.rect(0,h-6,w,6,stroke=0,fill=1)
    canvas.setFillColor(C_ACCENT); canvas.rect(0,0,5,h,stroke=0,fill=1)
    canvas.setFillColor(C_PANEL); canvas.rect(0,0,w,26*mm,stroke=0,fill=1)
    canvas.setFillColor(C_ACCENT); canvas.rect(0,26*mm,w,1.5,stroke=0,fill=1)
    canvas.setFillColor(C_MUTED); canvas.setFont("Helvetica",7)
    canvas.drawCentredString(w/2,12*mm,f"TrustScan Enterprise  ·  CONFIDENTIAL  ·  {datetime.now().year}")
    canvas.restoreState()


def page_bg(canvas, doc):
    canvas.saveState()
    w,h = A4
    canvas.setFillColor(C_BG); canvas.rect(0,0,w,h,stroke=0,fill=1)
    canvas.setFillColor(C_ACCENT); canvas.rect(0,h-6,w,6,stroke=0,fill=1)
    canvas.setFillColor(C_ACCENT); canvas.rect(0,0,4,h,stroke=0,fill=1)
    canvas.setFillColor(C_BORDER); canvas.rect(20*mm,20*mm,w-40*mm,0.5,stroke=0,fill=1)
    canvas.setFillColor(C_MUTED); canvas.setFont("Helvetica",7)
    canvas.drawCentredString(w/2,13*mm,
        f"TrustScan Enterprise  ·  {datetime.now().strftime('%B %d, %Y %H:%M UTC')}  ·  CONFIDENTIAL  ·  Page {doc.page}")
    canvas.restoreState()


def page_tmpl(canvas, doc):
    cover_bg(canvas, doc) if doc.page == 1 else page_bg(canvas, doc)


# ── HELPERS ───────────────────────────────────────────────────────────────────

def panel(text, st, color=C_ACCENT_L):
    t = Table([[Paragraph(text, st["body"])]], colWidths=[PW])
    t.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,-1), C_PANEL),
        ("LINEBEFORE",    (0,0),(0,-1),  4, color),
        ("TOPPADDING",    (0,0),(-1,-1), 14),
        ("BOTTOMPADDING", (0,0),(-1,-1), 14),
        ("LEFTPADDING",   (0,0),(-1,-1), 16),
        ("RIGHTPADDING",  (0,0),(-1,-1), 14),
    ]))
    return t


def kv_table(rows, c1=180):
    def mk(txt, bold=False, col=None):
        return Paragraph(str(txt or "—"), ParagraphStyle("kv",
            fontName="Helvetica-Bold" if bold else "Helvetica",
            fontSize=9, textColor=col or (C_TEXT if bold else C_TEXT_SEC)))
    data = [[mk(r[0]), mk(r[1], bold=True, col=r[2] if len(r)>2 else None)] for r in rows]
    t = Table(data, colWidths=[c1, PW-c1])
    t.setStyle(TableStyle([
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[C_PANEL,C_PANEL_ALT]),
        ("TOPPADDING",   (0,0),(-1,-1), 9),
        ("BOTTOMPADDING",(0,0),(-1,-1), 9),
        ("LEFTPADDING",  (0,0),(-1,-1), 12),
        ("RIGHTPADDING", (0,0),(-1,-1), 12),
        ("LINEBELOW",    (0,0),(-1,-2), 0.4, C_BORDER),
    ]))
    return t


def score_table(security, domain, reputation, score, st):
    dom      = domain or {}
    age_days = dom.get("age_days")
    ssl      = security.get("ssl") or {}

    def p(txt, sty): return Paragraph(txt, st[sty])

    def pts(val, ok_pts, bad_pts):
        return (p(ok_pts, "tok") if val else p(bad_pts, "tbad"))

    rows = [
        [p("SECURITY VECTOR","th"), p("REAL VALUE","th"), p("SEVERITY","th"), p("SCORE","th")],

        [p("HTTPS Encryption","tv"),
         p("Enabled" if security.get("https") else "Missing","tok" if security.get("https") else "tbad"),
         p("Critical","tv"),
         pts(security.get("https"),"15/15","0/15")],

        [p("SSL Certificate","tv"),
         p(f"Valid · {ssl.get('issuer','Unknown')} · {ssl.get('days_left','?')}d left"
           if ssl.get("valid") else "Invalid / Missing","tok" if ssl.get("valid") else "tbad"),
         p("Critical","tv"),
         pts(ssl.get("valid"),"15/15","0/15")],

        [p("Content-Security-Policy","tv"),
         p("Present" if security.get("headers",{}).get("csp") else "Absent",
           "tok" if security.get("headers",{}).get("csp") else "tbad"),
         p("High","tv"),
         pts(security.get("headers",{}).get("csp"),"10/10","0/10")],

        [p("X-Frame-Options","tv"),
         p("Present" if security.get("headers",{}).get("xframe") else "Absent",
           "tok" if security.get("headers",{}).get("xframe") else "tbad"),
         p("High","tv"),
         pts(security.get("headers",{}).get("xframe"),"10/10","0/10")],

        [p("Domain Age","tv"),
         p(f"{dom.get('age_years','N/A')} yrs — {dom.get('creation_date','?')}"
           if age_days else "WHOIS unavailable",
           "tok" if (age_days or 0)>180 else "tbad"),
         p("Medium","tv"),
         pts((age_days or 0)>180,"20/20","0/20")],

        [p("Redirect Chain","tv"),
         p(f"{security.get('redirects',0)} hop(s) — OK"
           if security.get("redirects",0)<3
           else f"{security.get('redirects',0)} hops — EXCESSIVE",
           "tok" if security.get("redirects",0)<3 else "tbad"),
         p("Medium","tv"),
         pts(security.get("redirects",0)<3,"10/10","0/10")],

        [p("Threat Intelligence","tv"),
         p("FLAGGED — malicious" if reputation.get("malicious") else "Clean — no threats",
           "tbad" if reputation.get("malicious") else "tok"),
         p("Critical","tv"),
         pts(not reputation.get("malicious"),"20/20","0/20")],

        [p("COMPOSITE TRUST SCORE","ttot"),
         p("","tv"), p("","tv"),
         p(f"{score} / 100","ttot")],
    ]

    t = Table(rows, colWidths=[175,200,70,70])
    t.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,0),  C_HDR_BG),
        ("ROWBACKGROUNDS",(0,1),(-1,-2), [C_PANEL,C_PANEL_ALT]),
        ("BACKGROUND",    (0,-1),(-1,-1),colors.HexColor("#0d2040")),
        ("LINEBELOW",     (0,0),(-1,0),  0.5,C_BORDER),
        ("LINEABOVE",     (0,-1),(-1,-1),1.5,C_ACCENT),
        ("LINEBELOW",     (0,-1),(-1,-1),1.5,C_ACCENT),
        ("TOPPADDING",    (0,0),(-1,-1), 9),
        ("BOTTOMPADDING", (0,0),(-1,-1), 9),
        ("LEFTPADDING",   (0,0),(-1,-1), 10),
        ("RIGHTPADDING",  (0,0),(-1,-1), 10),
        ("VALIGN",        (0,0),(-1,-1), "MIDDLE"),
    ]))
    return t


# ── MAIN BUILD ────────────────────────────────────────────────────────────────

def _build_pdf(scan_data: dict) -> bytes:
    url        = scan_data.get("url","Unknown")
    score      = scan_data.get("score",0)
    verdict    = (scan_data.get("verdict") or "SAFE").upper()
    scam_pct   = round(scan_data.get("scam_probability",0)*100)
    domain     = scan_data.get("domain") or {}
    security   = scan_data.get("security") or {}
    reputation = scan_data.get("reputation") or {}
    issues     = scan_data.get("issues") or []
    explanation= scan_data.get("explanation") or []
    geo        = scan_data.get("geo") or {}
    ai         = scan_data.get("ai") or {}

    v_col      = VERDICT_COLOR.get(verdict, C_ACCENT_L)
    st         = styles()
    buf        = io.BytesIO()
    ssl        = security.get("ssl") or {}
    dom        = domain
    age_days   = dom.get("age_days")
    age_str    = f"{dom.get('age_years')} yrs" if dom.get("age_years") else "Unavailable"
    rep_col    = C_RISKY if reputation.get("malicious") else C_SAFE
    scan_id    = "TS-" + hashlib.md5(f"{url}{time.time()}".encode()).hexdigest()[:10].upper()
    ai_powered = ai.get("ai_powered", False)
    now        = datetime.now()

    doc = SimpleDocTemplate(buf, pagesize=A4,
        leftMargin=20*mm, rightMargin=20*mm,
        topMargin=20*mm, bottomMargin=28*mm)
    s = []

    # ── PAGE 1: COVER ─────────────────────────────────────────────────────────
    s.append(Spacer(1,26*mm))
    badge = Table([[Paragraph(
        "● ENTERPRISE SECURITY ASSESSMENT REPORT  ·  REAL-TIME MULTI-VECTOR SCAN",
        ParagraphStyle("badge",fontName="Helvetica-Bold",fontSize=8,textColor=C_ACCENT_L)
    )]], colWidths=[PW])
    badge.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),colors.HexColor("#0a1628")),
        ("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8),
        ("LEFTPADDING",(0,0),(-1,-1),14)]))
    s.append(badge); s.append(Spacer(1,8*mm))
    s.append(Paragraph("Website Trust &amp;<br/>Security Intelligence Report", st["cover_title"]))
    s.append(Spacer(1,2*mm))
    s.append(Paragraph(
        "Real-time automated security assessment — SSL/TLS analysis, HTTP security headers, "
        "domain provenance, redirect chain, IP geolocation, and threat intelligence.",
        st["cover_sub"]))
    s.append(Spacer(1,8*mm))

    url_panel = Table([[[Paragraph("TARGET URL",st["label"]),Paragraph(url,st["url_s"])]]],colWidths=[PW])
    url_panel.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),C_PANEL),
        ("LINEBEFORE",(0,0),(0,-1),4,C_ACCENT_L),("TOPPADDING",(0,0),(-1,-1),12),
        ("BOTTOMPADDING",(0,0),(-1,-1),12),("LEFTPADDING",(0,0),(-1,-1),14),
        ("RIGHTPADDING",(0,0),(-1,-1),14)]))
    s.append(url_panel); s.append(Spacer(1,6*mm))

    vp = Table([[
        [Paragraph("VERDICT",st["label"]),Spacer(1,4),
         Paragraph(verdict,ParagraphStyle("vbig",fontName="Helvetica-Bold",fontSize=36,textColor=v_col)),
         Spacer(1,4),
         Paragraph(f"Trust Score: {score}/100  ·  Scam Probability: {scam_pct}%",
             ParagraphStyle("vsub",fontName="Helvetica",fontSize=10,textColor=C_TEXT_SEC))],
        ScoreDonut(score,verdict,size=130),
    ]],colWidths=[PW*0.70,PW*0.30])
    vp.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),C_PANEL_ALT),
        ("TOPPADDING",(0,0),(-1,-1),18),("BOTTOMPADDING",(0,0),(-1,-1),18),
        ("LEFTPADDING",(0,0),(-1,-1),18),("RIGHTPADDING",(0,0),(-1,-1),10),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LINEABOVE",(0,0),(-1,0),2.5,v_col)]))
    s.append(vp); s.append(Spacer(1,6*mm))

    meta=[("REPORT ID",scan_id),("GENERATED",now.strftime("%d %b %Y")),
          ("SCAN TIME",now.strftime("%H:%M UTC")),("CLASSIFICATION","CONFIDENTIAL")]
    mt=Table([[
        [Paragraph(m[0],st["label"]),
         Paragraph(m[1],ParagraphStyle("mv",fontName="Helvetica-Bold",fontSize=9,textColor=C_TEXT))]
        for m in meta]],colWidths=[PW/4]*4)
    mt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),C_SURFACE),
        ("TOPPADDING",(0,0),(-1,-1),10),("BOTTOMPADDING",(0,0),(-1,-1),10),
        ("LEFTPADDING",(0,0),(-1,-1),12),("RIGHTPADDING",(0,0),(-1,-1),12),
        ("LINEAFTER",(0,0),(-2,-1),0.5,C_BORDER)]))
    s.append(mt); s.append(PageBreak())

    # ── PAGE 2: SCORE OVERVIEW ────────────────────────────────────────────────
    s.append(Spacer(1,4*mm))
    s.append(SectionHeader(1,"Risk Score Overview",
        subtitle="Composite trust scoring — real values from live scan",color=v_col))
    s.append(Spacer(1,4*mm))

    gap=5; sw=(PW-gap*3)/4
    scam_col = C_RISKY if scam_pct>60 else C_CAUTION if scam_pct>30 else C_SAFE
    age_col  = C_SAFE if (age_days or 0)>365 else C_CAUTION if (age_days or 0)>0 else C_RISKY
    sr=Table([[
        StatBox("VERDICT",verdict,sub="Classification",color=v_col,width=sw),
        StatBox("TRUST SCORE",f"{score}/100",sub="8-vector composite",color=v_col,width=sw),
        StatBox("SCAM PROBABILITY",f"{scam_pct}%",sub="Calculated",color=scam_col,width=sw),
        StatBox("DOMAIN AGE",age_str,sub="WHOIS verified",color=age_col,width=sw),
    ]],colWidths=[sw]*4,rowHeights=[84])
    sr.setStyle(TableStyle([("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
    s.append(sr); s.append(Spacer(1,5*mm))

    s.append(Paragraph("RISK GAUGE — SCORE POSITION",st["label"]))
    s.append(Spacer(1,2*mm))
    s.append(RiskGauge(score,width=PW)); s.append(Spacer(1,5*mm))

    banner_text={
        "SAFE":    f"✓  SAFE — {url} passed security assessment with a score of {score}/100.",
        "CAUTION": f"⚠  CAUTION — {url} scored {score}/100. Warning signals detected.",
        "RISKY":   f"✕  HIGH RISK — {url} scored {score}/100. Multiple dangerous indicators found.",
    }.get(verdict,"")
    bn=Table([[Paragraph(banner_text,st["vtext"])]],colWidths=[PW])
    bn.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),v_col),
        ("TOPPADDING",(0,0),(-1,-1),14),("BOTTOMPADDING",(0,0),(-1,-1),14),
        ("LEFTPADDING",(0,0),(-1,-1),16),("RIGHTPADDING",(0,0),(-1,-1),16)]))
    s.append(bn); s.append(Spacer(1,6*mm))

    # ── SCORE BREAKDOWN TABLE ─────────────────────────────────────────────────
    s.append(SectionHeader(2,"Score Breakdown",
        subtitle="Per-vector real values — every cell reflects live scan output",color=C_ACCENT_L))
    s.append(Spacer(1,3*mm))
    s.append(score_table(security, domain, reputation, score, st))
    s.append(Spacer(1,3*mm))

    mn=Table([[Paragraph("METHODOLOGY",st["label"]),
        Paragraph(f"8-vector weighted model. Critical (HTTPS+SSL+Threat Intel)=50pts. "
                  f"Headers (CSP+X-Frame)=20pts. Domain age=20pts. Redirects=10pts. "
                  f"Total: <b>{score}/100</b>.",
                  ParagraphStyle("mn",fontName="Helvetica",fontSize=8.5,textColor=C_TEXT_SEC,leading=13))
    ]],colWidths=[110,PW-110])
    mn.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),C_SURFACE),
        ("TOPPADDING",(0,0),(-1,-1),10),("BOTTOMPADDING",(0,0),(-1,-1),10),
        ("LEFTPADDING",(0,0),(-1,-1),12),("RIGHTPADDING",(0,0),(-1,-1),12),
        ("VALIGN",(0,0),(-1,-1),"TOP"),("LINEAFTER",(0,0),(0,-1),0.5,C_BORDER)]))
    s.append(mn); s.append(PageBreak())

    # ── PAGE 3: SSL + HEADERS ─────────────────────────────────────────────────
    s.append(Spacer(1,4*mm))
    s.append(SectionHeader(3,"SSL Certificate — Full Details",
        subtitle="Live certificate data from TLS socket handshake",color=C_ACCENT2))
    s.append(Spacer(1,3*mm))

    ssl_rows = [
        ["Status",        "Valid ✓" if ssl.get("valid") else "Invalid ✗",
                          C_SAFE if ssl.get("valid") else C_RISKY],
        ["Issued By",     ssl.get("issuer","Unknown")],
        ["Common Name",   ssl.get("issuer_cn","Unknown")],
        ["Subject",       ssl.get("subject","Unknown")],
        ["Expires",       ssl.get("expires","Unknown")],
        ["Days Remaining",str(ssl.get("days_left","Unknown")),
                          C_RISKY if (ssl.get("days_left") or 999)<30
                          else C_CAUTION if (ssl.get("days_left") or 999)<60
                          else C_SAFE],
        ["TLS Version",   ssl.get("tls_version","Unknown")],
    ]
    s.append(kv_table(ssl_rows)); s.append(Spacer(1,6*mm))

    s.append(SectionHeader(4,"HTTP Security Headers",
        subtitle="All headers detected in live HTTP response — real values shown",color=C_ACCENT2))
    s.append(Spacer(1,3*mm))

    all_h = security.get("all_headers",{})
    header_checks = [
        ("Content-Security-Policy",     "content-security-policy",
         security.get("headers",{}).get("csp",False),
         all_h.get("content-security-policy") or all_h.get("content-security-policy-report-only",""),
         "Prevents XSS attacks by restricting resource origins"),
        ("X-Frame-Options",             "x-frame-options",
         security.get("headers",{}).get("xframe",False),
         all_h.get("x-frame-options",""),
         "Blocks iframe embedding — prevents clickjacking"),
        ("Strict-Transport-Security",   "strict-transport-security",
         security.get("headers",{}).get("hsts",False),
         all_h.get("strict-transport-security",""),
         "Forces HTTPS — prevents SSL stripping attacks"),
        ("X-Content-Type-Options",      "x-content-type-options",
         security.get("headers",{}).get("xcontent",False),
         all_h.get("x-content-type-options",""),
         "Prevents MIME sniffing attacks"),
        ("Referrer-Policy",             "referrer-policy",
         security.get("headers",{}).get("referrer",False),
         all_h.get("referrer-policy",""),
         "Controls referrer information leakage"),
        ("Permissions-Policy",          "permissions-policy",
         security.get("headers",{}).get("permissions",False),
         all_h.get("permissions-policy",""),
         "Restricts browser feature access (camera, mic, etc.)"),
    ]
    for label, _, ok, val, detail in header_checks:
        display = val[:60] if val else ("Present" if ok else "Not set")
        s.append(CheckRow(label, ok, display, detail=detail))
    s.append(Spacer(1,6*mm))

    # Connection details
    s.append(SectionHeader(5,"Connection Details",
        subtitle="Real HTTP response metadata from live request",color=C_ACCENT_L))
    s.append(Spacer(1,3*mm))
    conn_rows = [
        ["IP Address",        security.get("ip","Unknown")],
        ["Hosting Provider",  geo.get("org","Unknown")],
        ["Country",           f"{geo.get('country','Unknown')} ({geo.get('country_code','??')})"],
        ["City",              geo.get("city","Unknown")],
        ["ASN",               geo.get("asn","Unknown")],
        ["Server",            security.get("server","Unknown")],
        ["HTTP Version",      security.get("http_version","Unknown")],
        ["Response Time",     f"{security.get('response_time_ms','?')} ms"],
        ["Redirect Count",    str(security.get("redirects",0))],
    ]
    s.append(kv_table(conn_rows)); s.append(Spacer(1,4*mm))

    # Redirect chain
    chain = security.get("redirect_chain",[])
    if chain:
        s.append(Paragraph("REDIRECT CHAIN",st["label"])); s.append(Spacer(1,2*mm))
        chain_rows=[[Paragraph("HOP",st["th"]),Paragraph("URL",st["th"]),Paragraph("STATUS",st["th"])]]
        for i,hop in enumerate(chain):
            chain_rows.append([
                Paragraph(str(i+1),ParagraphStyle("ci",fontName="Helvetica-Bold",fontSize=9,textColor=C_ACCENT_L)),
                Paragraph(hop.get("url","")[:70],ParagraphStyle("cu",fontName="Courier",fontSize=7.5,textColor=C_TEXT)),
                Paragraph(str(hop.get("status","")),ParagraphStyle("cs",fontName="Helvetica-Bold",fontSize=9,
                    textColor=C_SAFE if str(hop.get("status","")).startswith("3") else C_RISKY)),
            ])
        ct=Table(chain_rows,colWidths=[35,400,80])
        ct.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),C_HDR_BG),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_PANEL,C_PANEL_ALT]),
            ("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7),
            ("LEFTPADDING",(0,0),(-1,-1),8),("RIGHTPADDING",(0,0),(-1,-1),8),
            ("LINEBELOW",(0,0),(-1,-2),0.4,C_BORDER)]))
        s.append(ct)
    s.append(PageBreak())

    # ── PAGE 4: DOMAIN INTELLIGENCE ──────────────────────────────────────────
    s.append(Spacer(1,4*mm))
    s.append(SectionHeader(6,"Domain Intelligence",
        subtitle="Live WHOIS data — registrar, dates, name servers",color=C_PURPLE))
    s.append(Spacer(1,3*mm))

    days_to_exp = dom.get("days_to_expiry")
    exp_col = (C_RISKY if (days_to_exp or 999)<30 else
               C_CAUTION if (days_to_exp or 999)<90 else C_SAFE)
    dom_rows=[
        ["Registered Domain",  dom.get("domain","Unknown")],
        ["Registration Date",  dom.get("creation_date","Unknown"),
                               C_RISKY if dom.get("is_new") else C_TEXT],
        ["Expiry Date",        dom.get("expiry_date","Unknown"), exp_col],
        ["Days to Expiry",     str(days_to_exp) if days_to_exp else "Unknown", exp_col],
        ["Last Updated",       dom.get("updated_date","Unknown")],
        ["Domain Age",         age_str,
                               C_SAFE if (age_days or 0)>365 else C_CAUTION if (age_days or 0)>180 else C_RISKY],
        ["Registrar",          dom.get("registrar","Unknown")],
        ["New Domain Flag",    "Yes — under 180 days" if dom.get("is_new") else
                               ("No — established" if age_days else "Unknown"),
                               C_RISKY if dom.get("is_new") else C_SAFE],
    ]
    s.append(kv_table(dom_rows))

    ns = dom.get("name_servers",[])
    if ns:
        s.append(Spacer(1,4*mm))
        s.append(Paragraph("NAME SERVERS",st["label"])); s.append(Spacer(1,2*mm))
        for n in ns[:4]:
            s.append(Paragraph(f"▸  {n}",ParagraphStyle("ns",fontName="Courier",fontSize=9,
                textColor=C_ACCENT_L,leading=14)))
    s.append(Spacer(1,6*mm))

    # ── THREAT REPUTATION ─────────────────────────────────────────────────────
    s.append(SectionHeader(7,"Threat Intelligence & Reputation",
        subtitle="Google Safe Browsing API result — real-time lookup",color=rep_col))
    s.append(Spacer(1,3*mm))

    rep_rows=[
        ["Malicious Flag",     "YES — FLAGGED" if reputation.get("malicious") else "No — Clean",
                               C_RISKY if reputation.get("malicious") else C_SAFE],
        ["Source",             "Google Safe Browsing API v4"],
        ["Threat Types Checked","MALWARE, SOCIAL_ENGINEERING"],
        ["Platform Coverage",  "ANY_PLATFORM"],
        ["API Key Configured", "No — check skipped" if reputation.get("error","").startswith("API key") else "Yes"],
        ["Lookup Result",      reputation.get("error","No threats found") if not reputation.get("malicious")
                               else "ACTIVE THREAT — malware or phishing detected"],
    ]
    s.append(kv_table(rep_rows))
    s.append(Spacer(1,6*mm))

    # ── AI ANALYSIS ───────────────────────────────────────────────────────────
    s.append(SectionHeader(8,"AI Security Analysis",
        subtitle="Scam pattern detection + plain-English summary",color=C_PURPLE))
    s.append(Spacer(1,2*mm))
    s.append(AIBadge(ai_powered)); s.append(Spacer(1,3*mm))

    s.append(Paragraph("SCAM PATTERN DETECTION", st["label"])); s.append(Spacer(1,2*mm))
    s.append(panel(ai.get("scam_pattern","Analysis unavailable."), st, C_PURPLE))
    s.append(Spacer(1,4*mm))

    s.append(Paragraph("PLAIN-ENGLISH SUMMARY FOR USERS", st["label"])); s.append(Spacer(1,2*mm))
    s.append(panel(ai.get("summary","Summary unavailable."), st, v_col))
    s.append(PageBreak())

    s.append(PageBreak())

    # ── PAGE 5: ISSUES + INTEL ────────────────────────────────────────────────
    s.append(Spacer(1,4*mm))
    s.append(SectionHeader(9,"Detected Issues",
        subtitle=f"{len(issues)} issue(s) found across all security vectors",
        color=C_RISKY if issues else C_SAFE))
    s.append(Spacer(1,3*mm))

    if issues:
        imp_map = {
            "HTTPS":    "All data in transit is visible to network-level attackers.",
            "SSL":      "Server identity unverifiable — MITM attacks possible.",
            "CSP":      "XSS injection attacks may execute in user browsers.",
            "X-Frame":  "Clickjacking via malicious iframe embedding is possible.",
            "redirect": "Redirect chain may route users to malicious destinations.",
            "domain":   "New domains are disproportionately used in fraud campaigns.",
            "malicious":"Confirmed active threat — malware or phishing infrastructure.",
            "default":  "This finding reduces overall trust and increases risk.",
        }
        rec_map = {
            "HTTPS":    "Enforce HTTPS via server config; obtain a valid TLS certificate.",
            "SSL":      "Renew certificate from a trusted CA before expiry.",
            "CSP":      "Implement CSP header restricting script and resource origins.",
            "X-Frame":  "Add X-Frame-Options: DENY or SAMEORIGIN.",
            "redirect": "Reduce redirect chain to 2 hops or fewer.",
            "domain":   "Verify operator identity via official channels before trusting.",
            "malicious":"Do not interact. Report to Google Safe Browsing.",
            "default":  "Remediate per OWASP guidelines and re-scan.",
        }
        for i, issue in enumerate(issues):
            key = next((k for k in imp_map if k.lower() in issue.lower()), "default")
            col = C_RISKY if i%2==0 else C_CAUTION
            bg  = C_RISKY_BG if i%2==0 else C_CAUTION_BG
            sev = "HIGH SEVERITY" if col==C_RISKY else "MEDIUM SEVERITY"
            card=Table([[
                [Table([[
                    Paragraph(f"FINDING #{i+1:02d}",ParagraphStyle("fn",fontName="Helvetica-Bold",fontSize=7,textColor=col)),
                    Paragraph(sev,ParagraphStyle("fs",fontName="Helvetica-Bold",fontSize=7,textColor=col,alignment=TA_RIGHT)),
                ]],colWidths=[240,230]),
                Spacer(1,5),
                Paragraph(issue,ParagraphStyle("it",fontName="Helvetica-Bold",fontSize=9.5,textColor=col,spaceAfter=4)),
                Table([[
                    [Paragraph("IMPACT",st["label"]),
                     Paragraph(imp_map[key],ParagraphStyle("iv",fontName="Helvetica",fontSize=8.5,textColor=C_TEXT_SEC,leading=13))],
                    [Paragraph("REMEDIATION",st["label"]),
                     Paragraph(rec_map[key],ParagraphStyle("rv",fontName="Helvetica",fontSize=8.5,textColor=C_TEXT_SEC,leading=13))],
                ]],colWidths=[237,238]),
                ]
            ]],colWidths=[PW])
            card.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),bg),
                ("LINEBEFORE",(0,0),(0,-1),4,col),("TOPPADDING",(0,0),(-1,-1),14),
                ("BOTTOMPADDING",(0,0),(-1,-1),14),("LEFTPADDING",(0,0),(-1,-1),14),
                ("RIGHTPADDING",(0,0),(-1,-1),12),("LINEBELOW",(0,0),(-1,-1),0.5,col)]))
            s.append(KeepTogether([card,Spacer(1,3*mm)]))
    else:
        s.append(panel(f"No risk findings identified for <b>{url}</b>. "
                       "The site passed all evaluated security checks.", st, C_SAFE))
    s.append(Spacer(1,5*mm))

    # Intelligence summary (real explanation lines)
    s.append(SectionHeader(10,"Security Intelligence Summary",
        subtitle="Real findings from each scan module",color=C_ACCENT_L))
    s.append(Spacer(1,3*mm))
    for i,line in enumerate(explanation):
        row=Table([[
            Paragraph(f"{i+1:02d}",ParagraphStyle("in",fontName="Helvetica-Bold",fontSize=11,
                textColor=C_ACCENT_L,alignment=TA_CENTER)),
            Paragraph(line,ParagraphStyle("il",fontName="Helvetica",fontSize=9,
                textColor=C_TEXT,leading=14)),
        ]],colWidths=[36,PW-36])
        row.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1),C_PANEL if i%2==0 else C_PANEL_ALT),
            ("VALIGN",(0,0),(-1,-1),"MIDDLE"),("TOPPADDING",(0,0),(-1,-1),10),
            ("BOTTOMPADDING",(0,0),(-1,-1),10),("LEFTPADDING",(0,0),(-1,-1),10),
            ("RIGHTPADDING",(0,0),(-1,-1),12),("LINEBELOW",(0,0),(-1,-1),0.4,C_BORDER),
            ("LINEAFTER",(0,0),(0,-1),1.5,C_ACCENT_L)]))
        s.append(row); s.append(Spacer(1,2))
    s.append(PageBreak())

    # ── PAGE 6: RECOMMENDATIONS ───────────────────────────────────────────────
    s.append(Spacer(1,4*mm))
    s.append(SectionHeader(11,"Recommendations",
        subtitle=f"Action guidance based on {verdict} classification — verdict-specific",color=v_col))
    s.append(Spacer(1,3*mm))

    recs={
        "SAFE":[
            ("Verify Domain Authenticity","Check URL character-by-character for homoglyphs or typosquatting before entering credentials."),
            ("Confirm Browser Certificate","Click the padlock icon and verify the certificate chain and issuer match the expected organisation."),
            ("Request Missing Headers",
             f"{'Contact the site operator to implement CSP and X-Frame-Options headers.' if not security.get('headers',{}).get('csp') else 'Security headers are correctly configured — no action needed.'}"),
            ("Schedule Re-scans","Re-scan every 30 days. Security posture changes — certificates expire, headers get removed."),
        ],
        "CAUTION":[
            ("Do Not Submit Sensitive Data",f"Avoid passwords, payment details, or PII on {url} until independently verified."),
            ("Cross-Reference","Submit this URL to virustotal.com and urlscan.io for additional signal sources."),
            ("Check for Typosquatting","Compare character-by-character against the known legitimate domain."),
            ("Contact Site Operator","If this is a known internal resource, contact the operator to fix the identified security gaps."),
        ],
        "RISKY":[
            ("Stop — Do Not Proceed",f"Close the tab immediately. Do not click any link or button on {url}."),
            ("Change All Passwords","If credentials were submitted, change them immediately across every service where reused."),
            ("Monitor Financial Accounts","Contact your bank if payment data was entered. Request card replacement if needed."),
            ("Report to Google","Submit at safebrowsing.google.com/safebrowsing/report_phish/ to protect other users."),
            ("Run Anti-Malware Scan","Execute a full scan with Malwarebytes or Windows Defender on the device used."),
        ],
    }
    pri_labels=["CRITICAL","HIGH","MEDIUM","LOW","INFO"]
    pri_colors=[C_RISKY,C_CAUTION,C_ACCENT_L,C_SAFE,C_MUTED]
    for i,(title,desc) in enumerate(recs.get(verdict,[])):
        pc=pri_colors[min(i,len(pri_colors)-1)]
        rp=Table([[
            [Paragraph(f"{i+1:02d}",ParagraphStyle("rn",fontName="Helvetica-Bold",fontSize=20,textColor=v_col,alignment=TA_CENTER)),
             Paragraph(pri_labels[min(i,len(pri_labels)-1)],ParagraphStyle("rp",fontName="Helvetica-Bold",fontSize=6.5,textColor=pc,alignment=TA_CENTER))],
            [Paragraph(title,st["rec_title"]),Paragraph(desc,st["rec_body"])],
        ]],colWidths=[52,PW-52])
        rp.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),C_PANEL),
            ("BACKGROUND",(0,0),(0,-1),C_PANEL_ALT),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
            ("TOPPADDING",(0,0),(-1,-1),12),("BOTTOMPADDING",(0,0),(-1,-1),12),
            ("LEFTPADDING",(0,0),(-1,-1),12),("RIGHTPADDING",(0,0),(-1,-1),12),
            ("LINEBELOW",(0,0),(-1,-1),0.5,C_BORDER),("LINEAFTER",(0,0),(0,-1),2,v_col)]))
        s.append(rp); s.append(Spacer(1,2*mm))
    s.append(Spacer(1,5*mm)); s.append(PageDivider()); s.append(Spacer(1,4*mm))

    # ── PAGE 7: METHODOLOGY ───────────────────────────────────────────────────
    s.append(SectionHeader(12,"Methodology & Disclaimer",
        subtitle="Scan methodology, data sources, limitations, legal notices",color=C_MUTED))
    s.append(Spacer(1,3*mm))
    s.append(panel(
        "<b>Scan Methodology:</b> TrustScan performs a real-time 8-vector assessment. "
        "(1) HTTPS — URL scheme detection. "
        "(2) SSL/TLS — live socket handshake with full certificate extraction. "
        "(3) CSP header — HTTP response inspection with browser User-Agent. "
        "(4) X-Frame-Options — HTTP response inspection. "
        "(5) Domain age — WHOIS query with subdomain stripping. "
        "(6) Redirect chain — followed redirect history with per-hop URL and status. "
        "(7) Threat intelligence — Google Safe Browsing API v4. "
        "(8) IP geolocation — ipapi.co free endpoint."
        "<br/><br/>"
        "<b>AI Analysis:</b> "
        f"{'Scam pattern detection and plain-English summary were generated by Claude Sonnet via Puter.com, grounded strictly in real scan values for this URL. No data was invented.' if ai_powered else 'Puter auth token not configured — AI sections used rule-based analysis grounded in real scan data.'}"
        "<br/><br/>"
        "<b>Limitations:</b> Results are point-in-time. Threat intelligence databases may lag 24–72 hours. "
        "WHOIS data may be absent for privacy-protected registrations. "
        "Automated scanning cannot replace manual penetration testing."
        "<br/><br/>"
        "<b>Legal Notice:</b> For informational purposes only. Not legal, security, or financial advice. "
        "TrustScan accepts no liability for actions taken based on this report.",
        st, C_MUTED))
    s.append(Spacer(1,5*mm))
    s.append(HRFlowable(width="100%",thickness=0.5,color=C_BORDER))
    s.append(Spacer(1,3*mm))
    s.append(Paragraph(
        f"TrustScan Enterprise  ·  Report ID: {scan_id}  ·  "
        f"{now.strftime('%B %d, %Y at %H:%M UTC')}  ·  CONFIDENTIAL",
        st["footer"]))

    doc.build(s, onFirstPage=page_tmpl, onLaterPages=page_tmpl)
    return buf.getvalue()


async def generate_report(scan_data: dict) -> dict:
    try:
        pdf_bytes = await asyncio.to_thread(_build_pdf, scan_data)
        pdf_b64   = base64.b64encode(pdf_bytes).decode("utf-8")
        clean_url = (scan_data.get("url","report")
            .replace("https://","").replace("http://","")
            .replace("/","_")[:40])
        return {
            "status":     "ok",
            "pdf_base64": pdf_b64,
            "filename":   f"TrustScan_{clean_url}.pdf",
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}
