def calculate_score(url, security, domain, reputation):
    score       = 0
    issues      = []
    explanation = []

    # Normalize domain when WHOIS failed
    if domain.get("error") or domain.get("age_days") is None:
        domain_display = {
            "domain":        domain.get("domain"),
            "age_days":      None,
            "age_years":     None,
            "creation_date": None,
            "expiry_date":   None,
            "days_to_expiry":None,
            "updated_date":  None,
            "registrar":     domain.get("registrar"),
            "name_servers":  domain.get("name_servers", []),
            "is_new":        None,
        }
        age_days = None
    else:
        domain_display = domain
        age_days = domain.get("age_days", 0)

    # ── HTTPS (15 pts) ───────────────────────────
    if security.get("https"):
        score += 15
        explanation.append("HTTPS enabled — connection is encrypted.")
    else:
        issues.append("No HTTPS — connection is unencrypted.")
        explanation.append("No HTTPS — data transmitted in plaintext.")

    # ── SSL (15 pts) ─────────────────────────────
    ssl = security.get("ssl") or {}
    if ssl.get("valid"):
        score += 15
        if ssl.get("expiring_soon"):
            issues.append(f"SSL certificate expires in {ssl.get('days_left')} days.")
            explanation.append(f"SSL valid but expiring in {ssl.get('days_left')} days.")
        else:
            explanation.append(f"SSL valid — issued by {ssl.get('issuer', 'Unknown')}.")
    else:
        issues.append("Invalid or missing SSL certificate.")
        explanation.append("SSL invalid — site identity cannot be verified.")

    # ── CSP (10 pts) ──────────────────────────────
    if security.get("headers", {}).get("csp"):
        score += 10
        explanation.append("Content-Security-Policy header present.")
    else:
        issues.append("Missing Content-Security-Policy header.")
        explanation.append("No CSP header — vulnerable to XSS attacks.")

    # ── X-Frame (10 pts) ─────────────────────────
    if security.get("headers", {}).get("xframe"):
        score += 10
        explanation.append("X-Frame-Options present — clickjacking protected.")
    else:
        issues.append("Missing X-Frame-Options header.")
        explanation.append("No X-Frame-Options — vulnerable to clickjacking.")

    # ── HSTS — informational, not scored separately ────
    hsts_ok = security.get("headers", {}).get("hsts", False)
    if hsts_ok:
        explanation.append("HSTS header present — forces HTTPS on repeat visits.")
    else:
        explanation.append("No HSTS header — browser won't enforce HTTPS on repeat visits.")

    # ── Domain Age (20 pts) ──────────────────────
    if age_days is None:
        issues.append("Domain age unavailable — WHOIS data private or blocked.")
        explanation.append("Cannot verify domain age — WHOIS data unavailable.")
    elif age_days > 365 * 5:
        score += 20
        explanation.append(f"Domain established {domain_display['age_years']} years ago — strong provenance.")
    elif age_days > 180:
        score += 20
        explanation.append(f"Domain {domain_display['age_years']} years old — established.")
    else:
        issues.append(f"New domain — only {age_days} days old.")
        explanation.append(f"Domain only {age_days} days old — high-risk signal.")

    # ── Redirects (10 pts) ───────────────────────
    redirects = security.get("redirects", 0)
    if redirects < 3:
        score += 10
        explanation.append(f"{redirects} redirect(s) — acceptable.")
    else:
        issues.append(f"Excessive redirects ({redirects}).")
        explanation.append(f"{redirects} redirects — suspicious routing.")

    # ── Reputation (20 pts) ──────────────────────
    is_malicious    = reputation.get("malicious")
    rep_error       = reputation.get("error", "")
    api_key_missing = rep_error.startswith("API key missing") if rep_error else False
    # Only award points when malicious=False AND no error at all
    # A 403, timeout, or any API error means we don't know — don't award points
    rep_check_clean = is_malicious is False and not rep_error

    if is_malicious is True:
        issues.append("Flagged malicious by Google Safe Browsing.")
        explanation.append("Actively listed as malware or phishing in Google Safe Browsing.")
    elif rep_check_clean:
        score += 20
        explanation.append("Not flagged in Google Safe Browsing.")
    elif api_key_missing:
        explanation.append("Reputation check skipped — no API key configured.")
    elif rep_error:
        explanation.append(f"Reputation check failed: {rep_error[:60]}")
    else:
        explanation.append("Reputation check inconclusive.")

    # Verdict
    scam_probability = round((100 - score) / 100, 2)
    verdict = "SAFE" if score >= 80 else "CAUTION" if score >= 50 else "RISKY"

    return {
        "url":              url,
        "score":            score,
        "verdict":          verdict,
        "scam_probability": scam_probability,
        "domain":           domain_display,
        "security":         security,
        "reputation":       reputation,
        "issues":           issues,
        "explanation":      explanation,
    }
