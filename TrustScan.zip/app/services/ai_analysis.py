from typing import Optional
"""
ai_analysis.py
Real AI analysis via Puter.com — two specific tasks only:
  1. Scam pattern detection (is this combination of signals suspicious?)
  2. Plain-English summary for non-technical users

Both are grounded strictly in real scan data — no hallucination.
Falls back gracefully if Puter token is missing or call fails.
"""
import httpx
from app.config import PUTER_AUTH_TOKEN

PUTER_ENDPOINT = "https://api.puter.com/puterai/anthropic/v1/messages"
MODEL          = "claude-sonnet-4-6"


async def _call_puter(prompt: str, max_tokens: int = 300) -> Optional[str]:
    """Single call to Claude via Puter. Returns text or None on failure."""
    if not PUTER_AUTH_TOKEN:
        return None
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            res = await client.post(
                PUTER_ENDPOINT,
                headers={
                    "Authorization":    f"Bearer {PUTER_AUTH_TOKEN}",
                    "anthropic-version":"2023-06-01",
                    "content-type":     "application/json",
                },
                json={
                    "model":      MODEL,
                    "max_tokens": max_tokens,
                    "messages":   [{"role": "user", "content": prompt}],
                }
            )
            if res.status_code == 200:
                return res.json()["content"][0]["text"].strip()
    except Exception:
        pass
    return None


async def analyse(scan_data: dict) -> dict:
    """
    Run two AI tasks in parallel.
    Returns dict with keys: scam_pattern, summary, ai_powered
    All fallbacks are rule-based — never crashes.
    """
    url        = scan_data.get("url", "")
    score      = scan_data.get("score", 0)
    verdict    = scan_data.get("verdict", "UNKNOWN")
    scam_pct   = round(scan_data.get("scam_probability", 0) * 100)
    domain     = scan_data.get("domain") or {}
    security   = scan_data.get("security") or {}
    reputation = scan_data.get("reputation") or {}
    issues     = scan_data.get("issues") or []

    age_days   = domain.get("age_days")
    age_str    = f"{domain.get('age_years')} years" if domain.get("age_years") else "unknown"
    registrar  = domain.get("registrar") or "unknown"
    https_ok   = security.get("https", False)
    ssl_ok     = security.get("ssl", {}).get("valid", False)
    ssl_issuer = security.get("ssl", {}).get("issuer", "unknown")
    csp_ok     = security.get("headers", {}).get("csp", False)
    xframe_ok  = security.get("headers", {}).get("xframe", False)
    hsts_ok    = security.get("headers", {}).get("hsts", False)
    redirects  = security.get("redirects", 0)
    malicious  = reputation.get("malicious", False)
    server     = security.get("server", "unknown")
    ip         = security.get("ip", "unknown")
    hosting    = (scan_data.get("geo") or {}).get("org", "unknown")

    # ── PROMPT 1: Scam Pattern Detection ─────────────────────────────────────
    scam_prompt = f"""You are a cybersecurity analyst specialising in scam and phishing detection.

Analyse this real scan data and determine if the combination of signals matches known scam or phishing patterns.
Be specific — reference the actual values below. Do NOT invent data.

SCAN DATA:
- URL: {url}
- Trust Score: {score}/100
- Verdict: {verdict}
- Domain Age: {age_str}
- Registrar: {registrar}
- HTTPS: {https_ok}
- SSL Valid: {ssl_ok}, Issuer: {ssl_issuer}
- CSP Header: {csp_ok}
- X-Frame-Options: {xframe_ok}
- HSTS: {hsts_ok}
- Redirects: {redirects}
- Flagged Malicious: {malicious}
- Server: {server}
- IP: {ip}
- Hosting: {hosting}
- Detected Issues: {'; '.join(issues) if issues else 'None'}

Answer in exactly 2 sentences:
1. Does this match known scam/phishing patterns? Why or why not (cite specific signals)?
2. What type of site does this most likely represent based on the signals?

Be direct, factual, no filler."""

    # ── PROMPT 2: Plain-English Summary ──────────────────────────────────────
    summary_prompt = f"""You are explaining a website security scan to a non-technical user.

Based ONLY on this real scan data, write ONE plain-English paragraph (3 sentences max) explaining:
- Whether this site is safe to use
- The most important reason why (cite one specific real finding)
- What the user should do

REAL DATA:
- URL: {url}
- Trust Score: {score}/100  
- Verdict: {verdict}
- HTTPS: {https_ok}, SSL Valid: {ssl_ok}
- Domain Age: {age_str}
- Flagged Malicious: {malicious}
- Key Issues: {'; '.join(issues[:3]) if issues else 'None'}

Write for a non-technical person. No jargon. No markdown. No bullet points. Just plain sentences."""

    # ── Run both calls concurrently ───────────────────────────────────────────
    import asyncio
    scam_raw, summary_raw = await asyncio.gather(
        _call_puter(scam_prompt, max_tokens=150),
        _call_puter(summary_prompt, max_tokens=120),
    )

    # ── Fallbacks — rule-based, always real data ──────────────────────────────
    if not scam_raw:
        scam_raw = _fallback_scam_pattern(
            verdict, score, age_days, malicious, https_ok, ssl_ok, redirects, csp_ok
        )

    if not summary_raw:
        summary_raw = _fallback_summary(
            url, verdict, score, https_ok, ssl_ok, malicious, age_days, issues
        )

    return {
        "scam_pattern": scam_raw,
        "summary":      summary_raw,
        "ai_powered":   scam_raw is not None and PUTER_AUTH_TOKEN is not None,
    }


def _fallback_scam_pattern(verdict, score, age_days, malicious, https_ok, ssl_ok, redirects, csp_ok):
    signals = []
    if malicious:
        signals.append("active threat intelligence flag")
    if age_days is not None and age_days < 180:
        signals.append(f"domain only {age_days} days old")
    if not https_ok:
        signals.append("no HTTPS")
    if not ssl_ok:
        signals.append("invalid SSL")
    if redirects >= 3:
        signals.append(f"{redirects} redirects")
    if not csp_ok:
        signals.append("missing CSP header")

    if verdict == "RISKY":
        pattern = f"Yes — signals ({', '.join(signals[:3]) if signals else 'low score'}) are consistent with phishing or fraudulent site patterns."
        site_type = "High-risk site — likely phishing, scam, or malware distribution infrastructure."
    elif verdict == "CAUTION":
        pattern = f"Partial match — {', '.join(signals[:2]) if signals else 'moderate risk signals'} warrant caution but are not conclusive."
        site_type = "Possibly a new or poorly configured legitimate site, or an early-stage scam operation."
    else:
        pattern = "No significant scam pattern match — signals align with a legitimate, established website."
        site_type = "Appears to be a legitimate website with standard security configuration."

    return f"{pattern} {site_type}"


def _fallback_summary(url, verdict, score, https_ok, ssl_ok, malicious, age_days, issues):
    if verdict == "SAFE":
        key_reason = (
            "It uses a valid SSL certificate and has been established for "
            f"{'over a year' if (age_days or 0) > 365 else 'some time'}."
        )
        action = "You can proceed, but always verify the exact web address before entering passwords."
    elif verdict == "CAUTION":
        top_issue = issues[0] if issues else "some security controls are missing"
        key_reason = f"The main concern is: {top_issue.lower()}"
        action = "Do not enter passwords or payment details until you independently verify this site is legitimate."
    else:
        key_reason = (
            "It has been flagged as malicious." if malicious
            else f"It scored only {score}/100 due to: {issues[0].lower() if issues else 'multiple risk signals'}."
        )
        action = "Close this site immediately and do not interact with it."

    return (
        f"This website received a trust score of {score}/100 — it is classified as {verdict.lower()}. "
        f"{key_reason} {action}"
    )
