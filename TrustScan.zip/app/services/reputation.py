
import httpx
from app.config import GOOGLE_SAFE_BROWSING_API_KEY

async def check_reputation(url):
    if not GOOGLE_SAFE_BROWSING_API_KEY:
        # BUG FIX #2: return explicit False so scorer doesn't award bonus points on missing key
        return {"malicious": False, "error": "API key missing — reputation check skipped"}

    endpoint = f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={GOOGLE_SAFE_BROWSING_API_KEY}"

    payload = {
        "client": {
            "clientId": "trust-analyzer",
            "clientVersion": "2.0"
        },
        "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": url}]
        }
    }

    try:
        # BUG FIX #7: add explicit timeout so a slow Google API doesn't hang the scan
        async with httpx.AsyncClient(timeout=8) as client:
            res = await client.post(endpoint, json=payload)

            if res.status_code == 200:
                data = res.json()
                return {
                    "malicious": "matches" in data
                }

            return {"malicious": False, "error": f"Google API returned {res.status_code}"}

    except Exception as e:
        return {"malicious": False, "error": str(e)}
