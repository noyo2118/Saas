import whois
import httpx
from datetime import datetime, timezone
from app.utils import extract_domain


def _make_naive(dt):
    """Convert timezone-aware datetime to naive UTC. Returns None if not a datetime."""
    if dt is None:
        return None
    if not isinstance(dt, datetime):
        return None
    # BUG FIX: python-whois sometimes returns tz-aware datetimes
    # datetime.now() is naive — mixing them crashes with TypeError
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


def check_domain(url: str) -> dict:
    """WHOIS lookup — runs in thread pool (blocking)."""
    domain_name = extract_domain(url)
    try:
        d = whois.whois(domain_name)

        def pick(val):
            return val[0] if isinstance(val, list) else val

        creation_date = _make_naive(pick(d.creation_date))
        expiry_date   = _make_naive(pick(d.expiration_date))
        updated_date  = _make_naive(pick(d.updated_date))
        registrar     = pick(d.registrar) if d.registrar else None

        name_servers = d.name_servers
        if isinstance(name_servers, list):
            name_servers = list(dict.fromkeys(ns.lower().rstrip('.') for ns in name_servers))[:4]
        elif isinstance(name_servers, str):
            name_servers = [name_servers.lower().rstrip('.')]
        else:
            name_servers = []

        if not creation_date:
            return {
                "domain":         domain_name,
                "age_days":       None,
                "age_years":      None,
                "creation_date":  None,
                "expiry_date":    None,
                "days_to_expiry": None,
                "updated_date":   None,
                "registrar":      registrar,
                "name_servers":   name_servers,
                "is_new":         None,
                "error":          "WHOIS creation date unavailable",
            }

        now      = datetime.now(timezone.utc).replace(tzinfo=None)
        age_days = (now - creation_date).days

        days_to_expiry = None
        if expiry_date:
            try:
                days_to_expiry = (expiry_date - now).days
            except Exception:
                pass

        return {
            "domain":         domain_name,
            "age_days":       age_days,
            "age_years":      round(age_days / 365, 2),
            "creation_date":  str(creation_date)[:10],
            "expiry_date":    str(expiry_date)[:10] if expiry_date else None,
            "days_to_expiry": days_to_expiry,
            "updated_date":   str(updated_date)[:10] if updated_date else None,
            "registrar":      registrar,
            "name_servers":   name_servers,
            "is_new":         age_days < 180,
        }

    except Exception as e:
        return {
            "domain":         domain_name,
            "age_days":       None,
            "age_years":      None,
            "creation_date":  None,
            "expiry_date":    None,
            "days_to_expiry": None,
            "updated_date":   None,
            "registrar":      None,
            "name_servers":   [],
            "is_new":         None,
            "error":          str(e),
        }


async def check_ip_geo(ip: str) -> dict:
    """Free IP geolocation via ipapi.co — no key needed."""
    if not ip:
        return {}
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(
                f"https://ipapi.co/{ip}/json/",
                headers={"User-Agent": "TrustScan/2.0"},
            )
            if r.status_code == 200:
                data = r.json()
                if "error" in data:
                    return {}
                return {
                    "country":      data.get("country_name"),
                    "country_code": data.get("country_code"),
                    "city":         data.get("city"),
                    "org":          data.get("org"),
                    "asn":          data.get("asn"),
                }
    except Exception:
        pass
    return {}
