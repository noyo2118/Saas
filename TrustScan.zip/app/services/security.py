import asyncio
import httpx
import ssl
import socket
import time
from datetime import datetime, timezone
from urllib.parse import urlparse
from app.config import TIMEOUT

BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

SECURITY_HEADERS = [
    "content-security-policy",
    "content-security-policy-report-only",
    "x-frame-options",
    "strict-transport-security",
    "x-content-type-options",
    "referrer-policy",
    "permissions-policy",
    "x-xss-protection",
    "cross-origin-opener-policy",
    "cross-origin-embedder-policy",
]


def check_ssl(hostname: str) -> dict:
    """Full SSL cert extraction — runs in thread pool."""
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert    = ssock.getpeercert()
                version = ssock.version()

                # Parse expiry
                expires_str = cert.get("notAfter", "")
                expires_dt  = None
                days_left   = None
                try:
                    expires_dt = datetime.strptime(expires_str, "%b %d %H:%M:%S %Y %Z")
                    days_left  = (expires_dt - datetime.now(timezone.utc).replace(tzinfo=None)).days
                except Exception:
                    pass

                # Parse issuer
                issuer_dict = {}
                for item in cert.get("issuer", []):
                    for k, v in item:
                        issuer_dict[k] = v

                # Parse subject
                subject_dict = {}
                for item in cert.get("subject", []):
                    for k, v in item:
                        subject_dict[k] = v

                return {
                    "valid":        True,
                    "issuer":       issuer_dict.get("organizationName", issuer_dict.get("commonName", "Unknown")),
                    "issuer_cn":    issuer_dict.get("commonName", ""),
                    "subject":      subject_dict.get("commonName", hostname),
                    "expires":      expires_str,
                    "days_left":    days_left,
                    "tls_version":  version,
                    "expiry_ok":    (days_left is not None and days_left > 0),
                    "expiring_soon": (days_left is not None and 0 < days_left <= 30),
                }
    except Exception as e:
        return {"valid": False, "error": str(e)}


def resolve_ip(hostname: str) -> str:
    """DNS lookup — runs in thread pool."""
    try:
        return socket.gethostbyname(hostname)
    except Exception:
        return None


async def check_security(url: str) -> dict:
    hostname = urlparse(url).hostname
    t_start  = time.monotonic()

    result = {
        "https":         url.startswith("https"),
        "headers":       {},
        "all_headers":   {},
        "redirects":     0,
        "redirect_chain":[],
        "ssl":           {},
        "server":        None,
        "http_version":  None,
        "response_time_ms": None,
        "ip":            None,
    }

    try:
        async with httpx.AsyncClient(
            follow_redirects=True,
            timeout=TIMEOUT,
            headers={"User-Agent": BROWSER_UA},
        ) as client:
            r = await client.get(url)

        result["response_time_ms"] = round((time.monotonic() - t_start) * 1000)
        result["redirects"]        = len(r.history)
        result["http_version"]     = f"HTTP/{r.http_version}" if hasattr(r, "http_version") else None

        # Full redirect chain
        for resp in r.history:
            result["redirect_chain"].append({
                "url":    str(resp.url),
                "status": resp.status_code,
            })

        # Normalise all headers to lowercase
        h = {k.lower(): v for k, v in r.headers.items()}

        # Store all real header values for the report
        for hdr in SECURITY_HEADERS:
            if hdr in h:
                result["all_headers"][hdr] = h[hdr]

        result["server"] = h.get("server") or h.get("x-powered-by") or "Unknown"

        # Boolean flags for scoring
        result["headers"] = {
            "csp":          ("content-security-policy" in h or
                             "content-security-policy-report-only" in h),
            "xframe":       "x-frame-options" in h,
            "hsts":         "strict-transport-security" in h,
            "xcontent":     "x-content-type-options" in h,
            "referrer":     "referrer-policy" in h,
            "permissions":  "permissions-policy" in h,
        }

    except Exception as e:
        result["error"]   = str(e)
        result["ssl"]     = {"valid": False}
        result["headers"] = {k: False for k in ["csp","xframe","hsts","xcontent","referrer","permissions"]}
        result["response_time_ms"] = round((time.monotonic() - t_start) * 1000)

    # Run SSL + DNS concurrently in thread pool
    ssl_result, ip = await asyncio.gather(
        asyncio.to_thread(check_ssl, hostname),
        asyncio.to_thread(resolve_ip, hostname),
    )
    result["ssl"] = ssl_result
    result["ip"]  = ip

    return result
