import asyncio
import base64
import io

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from app.services.security   import check_security
from app.services.domain     import check_domain, check_ip_geo
from app.services.reputation import check_reputation
from app.services.scorer     import calculate_score
from app.services.ai_analysis import analyse
from app.services.cache      import get_cached, set_cache
from app.services.report     import generate_report
from app.utils               import normalize_url

router = APIRouter()


@router.post("/api/scan")
async def scan(data: dict):
    url = normalize_url(data.get("url"))
    if not url:
        raise HTTPException(status_code=400, detail="Invalid URL provided.")

    cached = get_cached(url)
    if cached:
        return cached

    try:
        # Run security + reputation concurrently
        security, reputation = await asyncio.gather(
            check_security(url),
            check_reputation(url),
        )

        # WHOIS in thread pool (blocking)
        domain = await asyncio.to_thread(check_domain, url)

        # IP geolocation using IP from security check
        geo = await check_ip_geo(security.get("ip"))

        # Build base scan result
        result = calculate_score(url, security, domain, reputation)
        result["geo"] = geo

        # AI analysis: scam pattern + plain English summary
        ai = await analyse(result)
        result["ai"] = ai

        set_cache(url, result)
        return result

    except Exception as e:
        # Sanitise — don't leak internal stack traces to clients
        raise HTTPException(status_code=500, detail="Scan failed. Please check the URL and try again.")


@router.post("/api/report")
async def report(data: dict):
    if not data or not data.get("url"):
        raise HTTPException(status_code=400, detail="Missing scan data or URL.")

    try:
        result = await generate_report(data)

        if result.get("status") == "error":
            raise HTTPException(
                status_code=500,
                detail=result.get("message", "Report generation failed.")
            )

        pdf_bytes = base64.b64decode(result["pdf_base64"])
        filename  = result.get("filename", "TrustScan_Report.pdf")

        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Report generation error: {e}")
