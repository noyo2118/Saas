import os
from dotenv import load_dotenv

load_dotenv()

GOOGLE_SAFE_BROWSING_API_KEY = os.getenv("GOOGLE_SAFE_BROWSING_API_KEY")
PUTER_AUTH_TOKEN             = os.getenv("PUTER_AUTH_TOKEN")
TIMEOUT                      = 10
