from urllib.parse import urlparse


def normalize_url(url: str) -> str:
    """
    Normalise a URL for consistent cache keys and scanning.
    - Adds https:// if no scheme
    - Lowercases scheme and hostname
    - Strips www. prefix
    - Strips trailing slashes
    - Strips subdomains (shop., m., api., etc.) for cache key consistency
    Returns None for invalid inputs.
    """
    if not url:
        return None
    url = url.strip()

    # Reject obviously non-HTTP schemes
    lower = url.lower()
    if lower.startswith(("javascript:", "data:", "file:", "ftp:", "mailto:")):
        return None

    if not lower.startswith("http"):
        url = "https://" + url

    try:
        parsed = urlparse(url)
        scheme   = parsed.scheme.lower()
        hostname = parsed.netloc.lower()

        # Strip port for hostname validation (keep it in netloc for URL)
        host_only = hostname.split(":")[0]

        if not host_only or "." not in host_only:
            return None

        # Strip www. from hostname
        if hostname.startswith("www."):
            hostname = hostname[4:]

        # Reconstruct with clean path (strip trailing slashes)
        path  = parsed.path.rstrip("/")
        query = f"?{parsed.query}" if parsed.query else ""
        return f"{scheme}://{hostname}{path}{query}"

    except Exception:
        return None


def extract_domain(url: str) -> str:
    """
    Return bare registrable domain for WHOIS lookup.
    Strips www., subdomains, ports.
    Handles 2-part TLDs (co.in, com.au, co.uk, etc.)
    """
    if not url:
        return ""
    try:
        parsed   = urlparse(url)
        hostname = parsed.netloc or parsed.path
        hostname = hostname.split(":")[0].lower().strip()
    except Exception:
        hostname = url.lower().strip()

    # Strip www.
    if hostname.startswith("www."):
        hostname = hostname[4:]

    # Handle known 2-part TLDs
    two_part_tlds = {
        "co.in",  "com.au", "co.uk",  "org.uk", "net.au",
        "com.br", "co.za",  "co.nz",  "com.sg", "co.jp",
        "org.in", "net.in", "gov.in", "edu.au",
    }
    parts    = hostname.split(".")
    last_two = ".".join(parts[-2:])

    if len(parts) > 2:
        if last_two in two_part_tlds:
            return ".".join(parts[-3:])   # e.g. shop.flipkart.co.in → flipkart.co.in
        else:
            return ".".join(parts[-2:])   # e.g. shop.myntra.com → myntra.com

    return hostname
