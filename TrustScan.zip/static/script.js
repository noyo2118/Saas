'use strict';

/* ── DOM REFS ───────────────────────────────── */
const $ = (id) => document.getElementById(id);

const els = {
  urlInput:       $('urlInput'),
  scanBtn:        $('scanBtn'),
  toast:          $('toast'),
  hero:           $('hero'),
  loaderSection:  $('loaderSection'),
  loaderUrl:      $('loaderUrl'),
  loaderStep:     $('loaderStep'),
  progressFill:   $('progressFill'),
  pipeline:       $('pipeline'),
  results:        $('results'),
  resetBtn:       $('resetBtn'),
  resultUrl:      $('resultUrl'),
  ringFill:       $('ringFill'),
  scoreGlow:      $('scoreGlow'),
  scoreNumber:    $('scoreNumber'),
  verdictBadge:   $('verdictBadge'),
  scamValue:      $('scamValue'),
  summaryUrl:     $('summaryUrl'),
  domainAge:      $('domainAge'),
  domainDate:     $('domainDate'),
  newDomainBadge: $('newDomainBadge'),
  securityChecks: $('securityChecks'),
  reputationBody: $('reputationBody'),
  issueList:      $('issueList'),
  issueCount:     $('issueCount'),
  explainList:    $('explainList'),
  reportBtn:      $('reportBtn'),
  reportStatus:   $('reportStatus'),
};

const PIPELINE_STEPS = [
  { label: 'Resolving domain…',            ms: 320 },
  { label: 'Checking SSL certificate…',    ms: 480 },
  { label: 'Analyzing security headers…',  ms: 600 },
  { label: 'Fetching domain age…',         ms: 750 },
  { label: 'Checking threat reputation…',  ms: 900 },
  { label: 'Computing trust score…',       ms: 200 },
];

const SVG = {
  check: `<svg class="check-icon" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="8" fill="rgba(52,211,153,0.12)" stroke="#34d399" stroke-width="1.3"/><path d="M5.5 9l2.5 2.5L13 6" stroke="#34d399" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  cross: `<svg class="check-icon" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="8" fill="rgba(248,113,113,0.1)" stroke="#f87171" stroke-width="1.3"/><path d="M6 6l6 6M12 6l-6 6" stroke="#f87171" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  warn:  `<svg class="check-icon" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="8" fill="rgba(251,191,36,0.1)" stroke="#fbbf24" stroke-width="1.3"/><path d="M9 6v4M9 11.5v.5" stroke="#fbbf24" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  issue: `<svg viewBox="0 0 14 14" fill="none"><path d="M7 1.5L1 13h12L7 1.5z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/><path d="M7 6v3M7 10.5v.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`,
  repOk: `<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="16" fill="rgba(52,211,153,0.08)" stroke="#34d399" stroke-width="1.5"/><path d="M12 20l5.5 5.5L28 14" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  repBad:`<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="16" fill="rgba(248,113,113,0.08)" stroke="#f87171" stroke-width="1.5"/><path d="M14 14l12 12M26 14L14 26" stroke="#f87171" stroke-width="2" stroke-linecap="round"/></svg>`,
  report:`<svg viewBox="0 0 16 16" fill="none"><rect x="2" y="1" width="10" height="13" rx="1.5" stroke="currentColor" stroke-width="1.3"/><path d="M5 5h5M5 7.5h5M5 10h3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/><path d="M10 11.5l1.5 1.5L14 10" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  ext:   `<svg viewBox="0 0 12 12" fill="none"><path d="M2 10L10 2M10 2H6M10 2v4" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

let scanning = false;
let pipelineTimers = [];
let lastScanData = null;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function normalizeUrl(raw) {
  raw = (raw || '').trim();
  if (!raw) return null;
  if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw;
  try {
    const u = new URL(raw);
    if (!u.hostname.includes('.')) return null;
    return raw;
  } catch { return null; }
}

function formatDate(str) {
  if (!str) return '—';
  try { return new Date(str).toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' }); }
  catch { return str; }
}

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

let toastTimer = null;
function showToast(msg) {
  els.toast.textContent = msg;
  els.toast.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.remove('visible'), 5000);
}

const RING_CIRCUMFERENCE = 314.16;

function animateScore(targetScore, verdict) {
  const colorMap = { SAFE:'var(--score-safe)', CAUTION:'var(--score-caution)', RISKY:'var(--score-risky)' };
  const glowMap  = {
    SAFE:   'radial-gradient(circle,rgba(52,211,153,0.2) 0%,transparent 70%)',
    CAUTION:'radial-gradient(circle,rgba(251,191,36,0.2) 0%,transparent 70%)',
    RISKY:  'radial-gradient(circle,rgba(248,113,113,0.2) 0%,transparent 70%)',
  };
  const color = colorMap[verdict] || colorMap.SAFE;
  els.ringFill.style.stroke = color;
  els.ringFill.style.filter = `drop-shadow(0 0 10px ${color})`;
  els.scoreGlow.style.background = glowMap[verdict] || glowMap.SAFE;
  const dur = 1200, t0 = performance.now();
  function step(now) {
    const t = Math.min((now-t0)/dur, 1), ease = 1-Math.pow(1-t,3);
    els.scoreNumber.textContent = Math.round(ease * targetScore);
    els.ringFill.style.strokeDashoffset = RING_CIRCUMFERENCE*(1-(ease*targetScore/100));
    if (t < 1) requestAnimationFrame(step);
    else els.scoreGlow.classList.add('visible');
  }
  requestAnimationFrame(step);
}

function startPipeline() {
  const items = els.pipeline.querySelectorAll('.pipeline-item');
  items.forEach(el => { el.removeAttribute('data-state'); el.querySelector('.pipeline-status').textContent='Pending'; });
  pipelineTimers = [];
  let delay = 300;
  PIPELINE_STEPS.forEach((step, i) => {
    const t1 = setTimeout(() => {
      if (items[i]) { items[i].setAttribute('data-state','active'); items[i].querySelector('.pipeline-status').textContent='Running…'; }
      els.loaderStep.textContent = step.label;
      els.progressFill.style.width = Math.round(((i+.5)/PIPELINE_STEPS.length)*85)+'%';
    }, delay);
    pipelineTimers.push(t1);
    delay += step.ms;
    const t2 = setTimeout(() => {
      if (items[i]) { items[i].setAttribute('data-state','done'); items[i].querySelector('.pipeline-status').textContent='Done'; }
    }, delay-60);
    pipelineTimers.push(t2);
  });
}

function finishPipeline() {
  pipelineTimers.forEach(clearTimeout);
  els.pipeline.querySelectorAll('.pipeline-item').forEach(el => {
    el.setAttribute('data-state','done'); el.querySelector('.pipeline-status').textContent='Done';
  });
  els.progressFill.style.width = '100%';
  els.loaderStep.textContent = 'Analysis complete.';
}

function showSection(name) {
  ['loaderSection','results'].forEach(id => $(id)?.classList.add('hidden'));
  if (name) $(name)?.classList.remove('hidden');
}

function staggerCards() {
  document.querySelectorAll('.stagger-item').forEach((c,i) => {
    c.classList.remove('visible');
    setTimeout(() => c.classList.add('visible'), 80+i*70);
  });
}

function buildSecurityChecks(security) {
  const {https, ssl, headers, redirects} = security;
  const items = [
    {label:'HTTPS Enabled',           ok:https,                icon:https?SVG.check:SVG.cross,          cls:https?'ok':'bad',          okT:'Secure',   badT:'Missing'},
    {label:'SSL Certificate',         ok:ssl?.valid,           icon:ssl?.valid?SVG.check:SVG.cross,     cls:ssl?.valid?'ok':'bad',     okT:'Valid',    badT:'Invalid'},
    {label:'Content-Security-Policy', ok:headers?.csp,         icon:headers?.csp?SVG.check:SVG.warn,   cls:headers?.csp?'ok':'warn',  okT:'Present',  badT:'Absent'},
    {label:'X-Frame-Options',         ok:headers?.xframe,      icon:headers?.xframe?SVG.check:SVG.warn,cls:headers?.xframe?'ok':'warn',okT:'Present', badT:'Absent'},
    {label:'Redirects',               ok:(redirects??0)<=2,    icon:(redirects??0)<=2?SVG.check:SVG.warn,cls:(redirects??0)<=2?'ok':'warn',okT:`${redirects??0} (OK)`,badT:`${redirects??0} (High)`},
  ];
  els.securityChecks.innerHTML = items.map(x => `<div class="check-item">${x.icon}<span class="check-label">${x.label}</span><span class="check-pill ${x.cls}">${x.ok?x.okT:x.badT}</span></div>`).join('');
}

function buildReputation(reputation) {
  if (reputation?.malicious) {
    els.reputationBody.innerHTML = `<div class="rep-danger">${SVG.repBad}<div class="rep-danger__title">⚠ Flagged as Malicious</div><div class="rep-danger__sub">Reported in Google Safe Browsing threat intelligence. Do not proceed.</div></div>`;
  } else {
    els.reputationBody.innerHTML = `<div class="rep-clean">${SVG.repOk}<div class="rep-clean__title">No Threats Detected</div><div class="rep-clean__sub">Not flagged in Google Safe Browsing or known threat intelligence feeds.</div></div>`;
  }
}

function buildIssues(issues) {
  els.issueCount.textContent = issues.length;
  if (!issues.length) { els.issueCount.classList.add('zero'); els.issueList.innerHTML=`<li class="issue-empty">${SVG.check} No issues detected.</li>`; return; }
  els.issueCount.classList.remove('zero');
  els.issueList.innerHTML = issues.map((x,i)=>`<li class="issue-item" style="animation-delay:${i*50}ms">${SVG.issue}${escapeHtml(x)}</li>`).join('');
}

function buildExplanation(explanation) {
  els.explainList.innerHTML = (explanation||[]).map((x,i)=>`<li class="explain-item" style="animation-delay:${i*60}ms"><span class="explain-bullet"></span>${escapeHtml(x)}</li>`).join('');
}

function renderResults(data) {
  lastScanData = data;
  const v = (data.verdict||'SAFE').toUpperCase();
  els.resultUrl.textContent  = `→ ${data.url||''}`;
  els.summaryUrl.textContent  = data.url||'—';
  els.scamValue.textContent   = data.scam_probability!=null ? `${Math.round(data.scam_probability*100)}%` : '—';
  els.verdictBadge.textContent = v;
  els.verdictBadge.className   = 'verdict-badge '+v.toLowerCase();
  animateScore(data.score??0, v);
  const d = data.domain||{};
  els.domainAge.textContent  = d.age_years!=null ? `${d.age_years.toFixed(1)} years` : '—';
  els.domainDate.textContent = formatDate(d.creation_date);
  els.newDomainBadge.classList.toggle('hidden', !(d.age_years!=null && d.age_years<0.5));
  buildSecurityChecks(data.security||{});
  buildReputation(data.reputation||{});
  buildIssues(data.issues||[]);
  buildExplanation(data.explanation||[]);
  setReportBtn('idle');
  showSection('results');
  staggerCards();
}

/* ── REPORT ─────────────────────────────────── */
function setReportBtn(state) {
  const btn = els.reportBtn, st = els.reportStatus;
  btn.onclick = generateReport;
  if (state === 'idle') {
    btn.disabled = false;
    btn.innerHTML = `${SVG.report} Generate PDF Report`;
    btn.className = 'report-btn';
    st.textContent = '';
    st.className = 'report-status';
  } else if (state === 'loading') {
    btn.disabled = true;
    btn.innerHTML = `<svg class="spin-inline" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5" stroke-dasharray="28" stroke-dashoffset="10" stroke-linecap="round"/></svg> Generating…`;
    btn.className = 'report-btn report-btn--loading';
    st.textContent = 'Generating enterprise PDF report with AI analysis — this takes 20–40 seconds…';
    st.className = 'report-status report-status--info';
  } else if (state === 'done') {
    btn.disabled = false;
    btn.innerHTML = `${SVG.report} Download Again`;
    btn.className = 'report-btn report-btn--done';
    st.textContent = 'PDF downloaded successfully.';
    st.className = 'report-status report-status--ok';
  } else if (state === 'error') {
    btn.disabled = false;
    btn.innerHTML = `${SVG.report} Retry Report`;
    btn.className = 'report-btn report-btn--error';
  }
}

async function generateReport() {
  if (!lastScanData) return;
  setReportBtn('loading');
  try {
    const res = await fetch('/api/report', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(lastScanData),
    });

    if (!res.ok) {
      // Error comes back as JSON
      let msg = `Server error (${res.status})`;
      try { msg = (await res.json()).detail || msg; } catch(_) {}
      els.reportStatus.textContent = msg;
      els.reportStatus.className = 'report-status report-status--error';
      setReportBtn('error');
      return;
    }

    // Success — response IS the PDF blob
    const blob = await res.blob();
    const filename = (res.headers.get('Content-Disposition') || '')
      .match(/filename="?([^"]+)"?/)?.[1] || 'TrustScan_Report.pdf';

    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(objectUrl), 10000);

    setReportBtn('done');

  } catch(err) {
    els.reportStatus.textContent = err.message || 'Network error during report generation.';
    els.reportStatus.className = 'report-status report-status--error';
    setReportBtn('error');
  }
}

/* ── SCAN ───────────────────────────────────── */
async function scan() {
  if (scanning) return;
  const url = normalizeUrl(els.urlInput.value);
  if (!url) { showToast('Please enter a valid URL — e.g. amazon.com'); els.urlInput.focus(); return; }
  scanning = true; lastScanData = null;
  els.scanBtn.disabled = true;
  els.toast.classList.remove('visible');
  els.hero.classList.add('hero--compact');
  els.loaderUrl.textContent = new URL(url).hostname;
  els.progressFill.style.width = '0%';
  els.loaderStep.textContent = 'Initializing…';
  showSection('loaderSection');
  startPipeline();
  try {
    const res = await fetch('/api/scan', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({url}) });
    finishPipeline();
    await sleep(400);
    if (!res.ok) { let m=`Server error (${res.status})`; try{m=(await res.json()).detail||m;}catch(_){} throw new Error(m); }
    renderResults(await res.json());
  } catch(err) {
    showSection(null);
    els.hero.classList.remove('hero--compact');
    showToast(err.message||'Scan failed. Please try again.');
  } finally {
    scanning = false;
    els.scanBtn.disabled = false;
  }
}

function reset() {
  pipelineTimers.forEach(clearTimeout);
  lastScanData = null;
  showSection(null);
  els.hero.classList.remove('hero--compact');
  els.urlInput.value = '';
  els.urlInput.focus();
  els.ringFill.style.strokeDashoffset = RING_CIRCUMFERENCE;
  els.scoreNumber.textContent = '0';
  els.scoreGlow.classList.remove('visible');
  els.progressFill.style.width = '0%';
}

els.scanBtn.addEventListener('click', scan);
els.urlInput.addEventListener('keydown', e => { if (e.key==='Enter') scan(); });
els.resetBtn.addEventListener('click', reset);
els.urlInput.addEventListener('input', () => els.toast.classList.remove('visible'));
document.querySelectorAll('.example-link').forEach(b => {
  b.addEventListener('click', () => { els.urlInput.value = b.dataset.url; els.urlInput.focus(); });
});

(function init() { els.urlInput.focus(); })();
