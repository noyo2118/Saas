# TrustScan — Website Trust Analyzer

A production-grade cybersecurity SaaS tool for scanning websites for SSL, domain age, security headers, and threat reputation.

---

## Project Structure

```
trust-analyzer/
├── app/
│   ├── main.py               # FastAPI app entry point
│   ├── routes.py             # API endpoints: /api/scan, /api/report
│   ├── config.py             # Environment variable loading
│   ├── utils.py              # URL normalization helpers
│   └── services/
│       ├── security.py       # HTTPS, SSL, headers, redirect checks
│       ├── domain.py         # WHOIS domain age lookup
│       ├── reputation.py     # Google Safe Browsing API
│       ├── scorer.py         # Trust score calculation + explanations
│       ├── report.py         # Gamma AI report generation
│       └── cache.py          # TTL cache (5 min, 1000 entries)
├── static/
│   ├── style.css             # Premium dark cybersecurity UI
│   └── script.js             # Vanilla JS — scan + report logic
├── templates/
│   └── index.html            # Main frontend (Jinja2)
├── .env                      # API keys (DO NOT COMMIT)
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure environment

Edit `.env`:

```
GOOGLE_SAFE_BROWSING_API_KEY=your_google_key_here
GAMMA_API_KEY=sk-gamma-your_gamma_key_here
```

- **Google Safe Browsing API**: https://developers.google.com/safe-browsing/v4/get-started
- **Gamma API key**: https://gamma.app → Settings → API Keys (Pro plan required)

### 3. Run

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Visit: http://localhost:8000

---

## API Endpoints

### `POST /api/scan`

Scan a URL for security signals.

**Request:**
```json
{ "url": "https://example.com" }
```

**Response:**
```json
{
  "url": "https://example.com",
  "score": 85,
  "verdict": "SAFE",
  "scam_probability": 0.15,
  "domain": { "age_years": 12.3, "creation_date": "2012-03-01", "is_new": false },
  "security": { "https": true, "ssl": { "valid": true }, "headers": { "csp": true, "xframe": true }, "redirects": 1 },
  "reputation": { "malicious": false },
  "issues": [],
  "explanation": ["HTTPS is enabled...", "SSL certificate is valid..."]
}
```

### `POST /api/report`

Generate a Gamma AI security report document.

**Request:** Pass the full `/api/scan` response body.

**Response:**
```json
{
  "status": "ok",
  "gamma_url": "https://gamma.app/...",
  "export_url": "https://...",
  "generation_id": "..."
}
```

---

## Score Breakdown

| Check | Points |
|---|---|
| HTTPS enabled | 15 |
| SSL certificate valid | 15 |
| CSP header present | 10 |
| X-Frame-Options present | 10 |
| Domain age > 180 days | 20 |
| Redirects < 3 | 10 |
| Not flagged in Safe Browsing | 20 |
| **Total** | **100** |

Verdicts: `SAFE` (≥80) · `CAUTION` (50–79) · `RISKY` (<50)

---

## Deployment (Northflank / any platform)

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Set env vars via your platform's secret manager. Never commit `.env`.
